/**
 * محولات مزودي ذكاء حقيقيين لبيئة Cloudflare Workers.
 * لا يوجد نوم طويل داخل خطوات الخلفية: بوابة Pollinations في المحرك إما تؤجل الخطوة
 * بمنبّه جديد أو تنتظر فقط في طلبات المالك المباشرة.
 */
export const PROVIDER_TYPES = [
  { id: "pollinations", name: "Pollinations — عام مجاني بدون مفتاح", needsKey: false, defaultBase: "https://text.pollinations.ai/openai" },
  { id: "openai_compatible", name: "OpenAI / OpenRouter / Groq / متوافق مع OpenAI", needsKey: true, defaultBase: "https://api.openai.com/v1" },
  { id: "anthropic", name: "Anthropic Claude", needsKey: true, defaultBase: "https://api.anthropic.com" },
  { id: "gemini", name: "Google Gemini", needsKey: true, defaultBase: "https://generativelanguage.googleapis.com" },
  { id: "ollama", name: "Ollama — خادم بعيد قابل للوصول من Cloudflare", needsKey: false, defaultBase: "http://127.0.0.1:11434" }
];

async function fetchJson(url, opts, timeoutMs = 120000) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const r = await fetch(url, { ...opts, signal: ctl.signal });
    const text = await r.text();
    let json;
    try { json = JSON.parse(text); } catch { json = { raw: text.slice(0, 2000) }; }
    if (!r.ok) {
      const e = new Error("المزود رد بـ HTTP " + r.status + ": " + text.slice(0, 400));
      e.status = r.status;
      e.body = json;
      throw e;
    }
    return json;
  } finally { clearTimeout(timer); }
}

function base(conn) {
  return (conn.baseUrl || PROVIDER_TYPES.find(t => t.id === conn.type)?.defaultBase || "").replace(/\/$/, "");
}

export async function chat(conn, apiKey, model, messages, { maxTokens = 2200, temperature = 0.6, rateGate = null, timeoutMs = 120000 } = {}) {
  if (!conn || !model) throw new Error("اتصال أو نموذج غير محدد");
  if (conn.type === "pollinations" && rateGate) await rateGate(conn);
  const b = base(conn);

  if (conn.type === "pollinations" || conn.type === "openai_compatible") {
    const headers = { "Content-Type": "application/json" };
    if (apiKey) headers.Authorization = "Bearer " + apiKey;
    const j = await fetchJson(b + "/chat/completions", {
      method: "POST",
      headers,
      body: JSON.stringify({ model, messages, max_tokens: maxTokens, temperature, tool_choice: "none" })
    }, timeoutMs);
    const msg = j?.choices?.[0]?.message;
    let text = String(msg?.content || "").trim();
    if (!text && Array.isArray(msg?.tool_calls) && msg.tool_calls.length) {
      const tc = msg.tool_calls[0] || {};
      const fn = tc.function || tc;
      let args = fn.arguments ?? tc.arguments ?? {};
      if (typeof args === "string") { try { args = JSON.parse(args); } catch { args = { query: args }; } }
      text = JSON.stringify({ action: "tool", tool: fn.name || tc.name || "", args });
    }
    if (!text) {
      const e = new Error("النموذج أعاد ردًا فارغ المحتوى (قد يكون استنفد رموز الاستدلال)");
      e.code = "EMPTY_RESPONSE";
      e.finishReason = j?.choices?.[0]?.finish_reason || null;
      throw e;
    }
    return { text, usage: j.usage || null, providerModel: j.model || model, requestId: j.id || null };
  }

  if (conn.type === "anthropic") {
    if (!apiKey) throw new Error("مفتاح Anthropic مفقود");
    const sys = messages.filter(m => m.role === "system").map(m => m.content).join("\n");
    const rest = messages.filter(m => m.role !== "system");
    const j = await fetchJson(b + "/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model,
        system: sys,
        messages: rest.map(m => ({ role: m.role === "assistant" ? "assistant" : "user", content: m.content })),
        max_tokens: maxTokens,
        temperature
      })
    }, timeoutMs);
    const text = (j?.content || []).filter(c => c.type === "text").map(c => c.text).join("\n").trim();
    if (!text) throw new Error("النموذج أعاد ردًا فارغًا");
    return { text, usage: j.usage || null, providerModel: j.model || model, requestId: j.id || null };
  }

  if (conn.type === "gemini") {
    if (!apiKey) throw new Error("مفتاح Gemini مفقود");
    const contents = messages.map(m => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: (m.role === "system" ? "[تعليمات نظام]\n" : "") + m.content }]
    }));
    const j = await fetchJson(
      b + "/v1beta/models/" + encodeURIComponent(model) + ":generateContent?key=" + encodeURIComponent(apiKey),
      { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ contents, generationConfig: { maxOutputTokens: maxTokens, temperature } }) },
      timeoutMs
    );
    const text = (j?.candidates?.[0]?.content?.parts || []).map(p => p.text || "").join("\n").trim();
    if (!text) throw new Error("النموذج أعاد ردًا فارغًا");
    return { text, usage: j.usageMetadata || null, providerModel: model, requestId: null };
  }

  if (conn.type === "ollama") {
    const j = await fetchJson(b + "/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model, messages, stream: false, options: { temperature, num_predict: maxTokens } })
    }, Math.max(timeoutMs, 180000));
    const text = String(j?.message?.content || "").trim();
    if (!text) throw new Error("النموذج البعيد أعاد ردًا فارغًا");
    return {
      text,
      usage: { prompt_tokens: j.prompt_eval_count, completion_tokens: j.eval_count },
      providerModel: j.model || model,
      requestId: null
    };
  }

  throw new Error("نوع مزود غير مدعوم: " + conn.type);
}

export async function listModels(conn, apiKey) {
  const b = base(conn);
  if (conn.type === "pollinations") {
    try {
      const list = await fetchJson("https://text.pollinations.ai/models", {}, 20000);
      const names = [...new Set((list || []).flatMap(m => [m.name, ...(m.aliases || [])]))];
      return { models: names.length ? names : ["openai-fast"], source: "من واجهة نماذج الخدمة لحظيًا" };
    } catch {
      return { models: ["openai-fast", "openai"], source: "بديل ثابت (تعذر جلب القائمة)" };
    }
  }
  if (conn.type === "openai_compatible") {
    const headers = {};
    if (apiKey) headers.Authorization = "Bearer " + apiKey;
    const j = await fetchJson(b + "/models", { headers }, 30000);
    return { models: (j.data || []).map(m => m.id).slice(0, 200), source: "من واجهة /models بالمزود" };
  }
  if (conn.type === "ollama") {
    const j = await fetchJson(b + "/api/tags", {}, 15000);
    return { models: (j.models || []).map(m => m.name), source: "من Ollama البعيد" };
  }
  return { models: [], source: "هذا المزود لا يعرض قائمة هنا — اكتب اسم النموذج يدويًا" };
}
