import { CompanyCore, PROVIDER_TYPES, TOOL_DEFS, uid, now } from "./engine-core.js";
import { chat, listModels } from "./providers.js";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,x-owner-token",
  "Access-Control-Allow-Methods": "GET,PUT,POST,DELETE,OPTIONS"
};

export class CompanyEngine extends CompanyCore {
  json(body, status = 200) {
    return new Response(JSON.stringify(body), {
      status,
      headers: { "Content-Type": "application/json; charset=utf-8", ...CORS }
    });
  }

  text(body, status = 200, type = "text/plain; charset=utf-8") {
    return new Response(body, { status, headers: { "Content-Type": type, ...CORS } });
  }

  async readJson(request) {
    const length = Number(request.headers.get("content-length") || 0);
    if (length > 15_000_000) throw new Error("جسم الطلب أكبر من الحد المسموح");
    const raw = await request.text();
    if (!raw) return {};
    try { return JSON.parse(raw); }
    catch { throw new Error("JSON غير صالح"); }
  }

  authed(request, url, path) {
    if (!this.ownerToken && this.env.ALLOW_OPEN_DEV === "true") return true;
    if (this.ownerToken && request.headers.get("x-owner-token") === this.ownerToken) return true;
    if (path.endsWith("/raw") && this.ownerToken && url.searchParams.get("token") === this.ownerToken) return true;
    return false;
  }

  async handleFetch(request) {
    const url = new URL(request.url);
    const path = url.pathname;

    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });

    if (path === "/__loop/wake" && request.method === "POST") {
      const expected = this.env.LOOP_WAKE_SECRET || "";
      if (expected && request.headers.get("x-loop-secret") !== expected) return this.json({ error: "سر حلقة غير صحيح" }, 403);
      try {
        const result = await this.wakeNow(request.headers.get("x-loop-source") || "cron");
        return this.json({ ok: true, result, loop: this.loopStatus() });
      } catch (e) {
        return this.json({ ok: false, error: String(e.message || e).slice(0, 400), loop: this.loopStatus() }, 500);
      }
    }

    if (!path.startsWith("/api/")) return this.json({ error: "غير موجود" }, 404);
    if (path === "/api/ping") {
      return this.json({ ok: true, service: "autonomous-ai-company-cloudflare-loop", time: new Date().toISOString() });
    }

    return this.withLock(async () => {
      let response;
      try {
        response = await this.route(request, url, path);
      } catch (e) {
        console.error(e);
        this.persist();
        response = this.json({ error: String(e.message || e).slice(0, 500) }, Number(e.status || 500));
      }

      this.store.flush();
      try {
        if (this.db.loop?.enabled) {
          const method = String(request.method || "GET").toUpperCase();
          if (method !== "GET" && response.status < 400 && path !== "/api/admin/wake") {
            if (this.hasPendingWork()) await this.ensureScheduled(1000, true);
            else await this.ensureScheduled(1000, false);
          } else if (method === "GET" && this.hasPendingWork()) {
            await this.ensureScheduled(1000, false);
          }
        }
      } catch (e) {
        console.warn("تعذر ضبط منبّه الحلقة:", e.message || e);
      }
      return response;
    });
  }

  async route(request, url, p) {
    const method = request.method;

    if (p === "/api/health" && method === "GET") {
      for (const agent of this.db.agents) this.normalizeSummon(agent);
      return this.json({
        ok: true,
        service: "autonomous-ai-company-cloudflare-loop",
        runtime: "cloudflare-workers-durable-objects-sqlite",
        time: new Date().toISOString(),
        authConfigured: !!this.ownerToken,
        encryptionConfigured: !!this.encryptionConfigured,
        ceoConfigured: this.isConfigured(this.ceo()),
        configuredAgents: this.db.agents.filter(a => !a.isCeo && this.isConfigured(a)).length + "/20",
        runningTasks: this.db.tasks.filter(t => t.status === "running").length,
        queuedTasks: this.db.tasks.filter(t => t.status === "queued").length,
        activeSummons: this.db.agents.filter(a => this.normalizeSummon(a, false).active).length,
        cloudinary: !!this.cloudinaryConfig(),
        loop: this.loopStatus(),
        storage: this.store.stats()
      });
    }

    if (!this.authed(request, url, p)) {
      return this.json({
        error: this.ownerToken ? "رمز مالك غير صحيح" : "OWNER_TOKEN غير مضبوط على Cloudflare؛ أضفه كـ Secret قبل الاستخدام"
      }, 401);
    }

    if (p === "/api/view" && method === "GET") {
      return this.json({
        company: this.db.company,
        serverTime: now(),
        agents: this.db.agents.map(a => this.agentView(a)),
        pendingApprovals: this.db.approvals.filter(a => a.status === "pending").length,
        projects: this.db.projects.map(x => ({ id: x.id, title: x.title, status: x.status, origin: x.origin })),
        ceoBusy: {
          planning: this.db.projects.some(x => x.status === "planning"),
          reviewing: this.db.tasks.some(x => x.status === "under_review"),
          scanning: !!this.db.loop.forceScan
        },
        loop: this.loopStatus()
      });
    }

    if (p === "/api/os" && method === "GET") {
      return this.json({
        company: this.db.company,
        settings: this.db.settings,
        providerTypes: PROVIDER_TYPES,
        toolDefs: TOOL_DEFS,
        connections: this.db.connections.map(c => this.safeConn(c)),
        agents: this.db.agents.map(a => this.agentView(a)),
        agentsConfig: this.db.agents.map(a => ({ id: a.id, systemPrompt: a.systemPrompt })),
        projects: [...this.db.projects].reverse(),
        tasks: [...this.db.tasks].reverse(),
        artifacts: [...this.db.artifacts].reverse().slice(0, 120),
        reviews: [...this.db.reviews].reverse().slice(0, 80),
        runs: [...this.db.runs].reverse().slice(0, 80).map(r => ({ ...r, messages: undefined, finalText: undefined })),
        approvals: [...this.db.approvals].reverse(),
        meetings: [...this.db.meetings].reverse(),
        activity: [...this.db.activity].reverse().slice(0, 150),
        ceoChat: this.db.ceoChat.slice(-100),
        agentChats: this.db.agentChats || {},
        decisions: [...this.db.decisions].reverse().slice(0, 40),
        loop: this.loopStatus()
      });
    }

    /* إدارة الحلقة والترحيل */
    if (p === "/api/admin/loop" && method === "GET") {
      return this.json({
        loop: this.loopStatus(),
        storage: this.store.stats(),
        taskStatuses: this.db.tasks.reduce((acc, t) => ((acc[t.status] = (acc[t.status] || 0) + 1), acc), {}),
        projectStatuses: this.db.projects.reduce((acc, x) => ((acc[x.status] = (acc[x.status] || 0) + 1), acc), {})
      });
    }
    if (p === "/api/admin/loop" && method === "POST") {
      const b = await this.readJson(request);
      this.db.loop.enabled = !!b.enabled;
      this.activity("حلقة Cloudflare", this.db.loop.enabled
        ? "☁️ شغّل المالك حلقة العمل السحابية؛ ستستيقظ الشركة تلقائيًا وتكمل من نقاط الحفظ."
        : "⏸️ أوقف المالك حلقة العمل السحابية مؤقتًا؛ الحالة والمهام محفوظة كما هي.");
      this.persist();
      if (this.db.loop.enabled) await this.ensureScheduled(1000, true);
      else await this.scheduleAfter({});
      return this.json({ ok: true, loop: this.loopStatus() });
    }
    if (p === "/api/admin/wake" && method === "POST") {
      if (!this.db.loop.enabled) return this.json({ error: "الحلقة متوقفة؛ شغّلها أولًا من /api/admin/loop" }, 409);
      const result = await this.advanceLoop("manual_api");
      return this.json({ ok: true, result, loop: this.loopStatus() });
    }
    if (p === "/api/admin/export" && method === "GET") return this.json(this.exportBundle());
    if (p === "/api/admin/import" && method === "POST") {
      const b = await this.readJson(request);
      const bundle = b.bundle || b;
      const summary = await this.importBundle(bundle, { pauseLoop: b.pauseLoop !== false });
      return this.json({ ok: true, summary });
    }

    /* الاتصالات */
    if (p === "/api/connections" && method === "POST") {
      const b = await this.readJson(request);
      const type = PROVIDER_TYPES.find(t => t.id === b.type);
      if (!type) return this.json({ error: "نوع مزود غير معروف" }, 400);
      if (type.needsKey && !String(b.apiKey || "").trim()) return this.json({ error: "هذا المزود يحتاج مفتاح API" }, 400);
      const apiKey = String(b.apiKey || "").trim();
      if (apiKey && !this.encryptionConfigured) {
        return this.json({ error: "ENCRYPTION_SECRET غير مضبوط على Cloudflare؛ أضفه كـ Secret أولًا حتى لا تُحفظ مفاتيح المزودين بسر مؤقت" }, 500);
      }
      const conn = {
        id: uid(), name: String(b.name || type.name), type: b.type,
        baseUrl: String(b.baseUrl || type.defaultBase),
        secret: await this.encSecret(apiKey || null),
        masked: apiKey ? (apiKey.slice(0, 3) + "••••••" + apiKey.slice(-4)) : "بدون مفتاح",
        models: Array.isArray(b.models) ? b.models : (b.model ? [String(b.model)] : []),
        enabled: true, createdAt: now(), lastTest: null
      };
      this.db.connections.push(conn);
      this.activity("اتصال", "🔌 أضاف المالك اتصال ذكاء «" + conn.name + "» (" + type.name + ").");
      this.persist();
      return this.json(this.safeConn(conn), 201);
    }

    if (p === "/api/connections/activate-free" && method === "POST") {
      let conn = this.db.connections.find(c => c.type === "pollinations");
      if (!conn) {
        conn = {
          id: uid(), name: "مزود عام مجاني (Pollinations)", type: "pollinations",
          baseUrl: "https://text.pollinations.ai/openai", secret: null, masked: "بدون مفتاح",
          models: ["openai-fast", "openai", "openai-large"], enabled: true, isPublicFree: true, createdAt: now()
        };
        this.db.connections.push(conn);
      }
      const b = await this.readJson(request);
      const model = b.model || "openai-fast";
      this.db.agents.forEach(a => { a.connectionId = conn.id; a.model = model; });
      this.db.tasks.forEach(t => { if (t.status === "blocked_unconfigured") t.status = "queued"; });
      this.activity("اتصال", "🔌 فعّل المالك المزود العام المجاني وعيّن نموذج " + model + " للمدير والفريق كاملًا. الشركة مهيأة الآن بنماذج حقيقية.");
      this.persist();
      return this.json({ ok: true, connection: this.safeConn(conn), model });
    }

    const mConn = p.match(/^\/api\/connections\/([\w-]+)(\/(test|models))?$/);
    if (mConn && mConn[1] !== "activate-free") {
      const conn = this.connById(mConn[1]);
      if (!conn) return this.json({ error: "الاتصال غير موجود" }, 404);
      if (method === "DELETE" && !mConn[2]) {
        this.db.connections = this.db.connections.filter(c => c.id !== conn.id);
        this.db.agents.forEach(a => { if (a.connectionId === conn.id) { a.connectionId = null; a.model = null; } });
        this.activity("اتصال", "حذف المالك اتصال «" + conn.name + "» وفُصل الوكلاء المرتبطون به.");
        this.persist();
        return this.json({ ok: true });
      }
      if (method === "POST" && mConn[3] === "models") {
        try {
          const r = await listModels(conn, await this.connKey(conn));
          if (r.models.length) {
            conn.models = [...new Set([...(conn.models || []), ...r.models])];
            this.persist();
          }
          return this.json(r);
        } catch (e) { return this.json({ error: "فشل جلب النماذج: " + e.message }, 502); }
      }
      if (method === "POST" && mConn[3] === "test") {
        const b = await this.readJson(request);
        const model = b.model || (conn.models || [])[0];
        if (!model) return this.json({ error: "أضف اسم نموذج أولًا" }, 400);
        const t0 = now();
        try {
          const r = await chat(conn, await this.connKey(conn), model,
            [{ role: "user", content: "أجب بكلمتين فقط: الاتصال يعمل" }],
            { maxTokens: 40, rateGate: c => this.rateGate(c, { background: false }) });
          conn.lastTest = { ok: true, at: now(), model, providerModel: r.providerModel, latencyMs: now() - t0, reply: r.text.slice(0, 120) };
          if (!(conn.models || []).includes(model)) conn.models = [...(conn.models || []), model];
          this.persist();
          return this.json(conn.lastTest);
        } catch (e) {
          conn.lastTest = { ok: false, at: now(), model, error: String(e.message || e).slice(0, 400) };
          this.persist();
          return this.json(conn.lastTest, 502);
        }
      }
      if (method === "PUT" && !mConn[2]) {
        const b = await this.readJson(request);
        if (b.name) conn.name = String(b.name);
        if (b.baseUrl) conn.baseUrl = String(b.baseUrl);
        if (Array.isArray(b.models)) conn.models = b.models.map(String);
        if (b.model) conn.models = [...new Set([...(conn.models || []), String(b.model)])];
        if (typeof b.enabled === "boolean") conn.enabled = b.enabled;
        if (b.apiKey && !this.encryptionConfigured) {
          return this.json({ error: "ENCRYPTION_SECRET غير مضبوط على Cloudflare؛ أضفه كـ Secret أولًا حتى لا تُحفظ مفاتيح المزودين بسر مؤقت" }, 500);
        }
        if (b.apiKey) {
          conn.secret = await this.encSecret(String(b.apiKey));
          conn.masked = String(b.apiKey).slice(0, 3) + "••••••" + String(b.apiKey).slice(-4);
        }
        this.persist();
        return this.json(this.safeConn(conn));
      }
    }

    /* الوكلاء */
    const mAgent = p.match(/^\/api\/agents\/([\w-]+)\/config$/);
    if (mAgent && method === "POST") {
      const agent = this.agentById(mAgent[1]);
      if (!agent) return this.json({ error: "الوكيل غير موجود" }, 404);
      const b = await this.readJson(request);
      agent.connectionId = b.connectionId || null;
      agent.model = b.model || null;
      if (Array.isArray(b.tools)) agent.tools = b.tools.filter(t => TOOL_DEFS.some(d => d.id === t));
      if (typeof b.systemPrompt === "string" && b.systemPrompt.trim()) agent.systemPrompt = b.systemPrompt;
      if (typeof b.role === "string" && b.role.trim()) agent.role = b.role.trim();
      this.db.tasks.forEach(t => {
        if (t.agentId === agent.id && t.status === "blocked_unconfigured" && this.isConfigured(agent)) t.status = "queued";
      });
      this.activity("تهيئة", "⚙️ حدّث المالك تهيئة " + agent.name + ": " +
        (this.isConfigured(agent) ? "نموذج " + agent.model + " عبر " + (this.connById(agent.connectionId)?.name || "—") : "أصبح غير مهيأ") + ".");
      this.persist();
      return this.json(this.agentView(agent));
    }

    if (p === "/api/agents/summon-all" && method === "POST") {
      const b = await this.readJson(request);
      const targets = this.db.agents.filter(a => this.isConfigured(a));
      targets.forEach(a => this.summonAgentRecord(a, b.durationMinutes || 30));
      this.activity("استدعاء", "📣 استدعى المالك كل الوكلاء المهيأين (" + targets.length + ") إلى مكتبه داخل المقر. لم تتوقف أي مهمة أو نقطة حفظ.");
      this.persist();
      return this.json({ ok: true, count: targets.length, agents: targets.map(a => this.agentView(a)) });
    }
    if (p === "/api/agents/dismiss-all" && method === "POST") {
      const targets = this.db.agents.filter(a => this.normalizeSummon(a, false).active);
      targets.forEach(a => this.dismissAgentRecord(a));
      this.activity("استدعاء", "↩️ أنهى المالك كل الاستدعاءات النشطة (" + targets.length + ") وأعاد الوكلاء بصريًا لمحطات عملهم.");
      this.persist();
      return this.json({ ok: true, count: targets.length });
    }

    const mSummon = p.match(/^\/api\/agents\/([\w-]+)\/(summon|dismiss|chat)$/);
    if (mSummon && method === "POST") {
      const agent = this.agentById(mSummon[1]);
      if (!agent) return this.json({ error: "الوكيل غير موجود" }, 404);
      const b = await this.readJson(request);
      if (mSummon[2] === "summon") {
        if (!this.isConfigured(agent)) {
          return this.json({ error: "لا يمكن استدعاء " + agent.name + " لأنه بلا نموذج ذكاء مربوط؛ تمثيله متوقف بصدق حتى تهيئته.", code: "AGENT_UNCONFIGURED" }, 409);
        }
        this.summonAgentRecord(agent, b.durationMinutes || 30);
        this.activity("استدعاء", "📣 استدعى المالك " + agent.name + " (" + agent.role + ") إلى مكتبه. أي مهمة جارية له تستمر من نقطة حفظها دون توقف.");
        this.persist();
        return this.json(this.agentView(agent));
      }
      if (mSummon[2] === "dismiss") {
        this.dismissAgentRecord(agent);
        this.activity("استدعاء", "↩️ أنهى المالك استدعاء " + agent.name + " وأعاده بصريًا لمحطة عمله.");
        this.persist();
        return this.json(this.agentView(agent));
      }

      if (!this.isConfigured(agent)) return this.json({ error: agent.name + " غير مهيأ بنموذج؛ لن أخترع ردًا باسمه.", code: "AGENT_UNCONFIGURED" }, 409);
      const msg = String(b.message || "").trim();
      if (!msg) return this.json({ error: "رسالة فارغة" }, 400);
      if (!Array.isArray(this.db.agentChats[agent.id])) this.db.agentChats[agent.id] = [];
      const mine = this.db.agentChats[agent.id];
      mine.push({ id: uid(), who: "owner", text: msg.slice(0, 4000), at: now() });
      const current = this.db.tasks.find(t => t.agentId === agent.id && ["running", "under_review", "queued"].includes(t.status));
      const latest = [...this.db.artifacts].reverse().find(x => x.agentId === agent.id);
      const latestText = latest?.kind === "text" ? this.artifactText(latest).slice(0, 2500) : "";
      const context = {
        الوكيل: { الاسم: agent.name, الدور: agent.role, القسم: agent.dept, النموذج: agent.model, الأدوات: agent.tools || [] },
        مهمته_الحالية: current ? {
          العنوان: current.title, الحالة: current.status, تعليمات_المدير: current.instructions,
          آخر_إجراء_موثق: current.lastAction || "", سبب_إسنادها: current.why || ""
        } : null,
        آخر_ناتج_محفوظ: latest ? { العنوان: latest.title, النوع: latest.kind, مقتطف: latestText } : null,
        ذاكرته: (agent.memory || []).slice(-8),
        حالة_الشركة: this.companyDigest(),
        مستدعى_لمكتب_المالك: this.normalizeSummon(agent, false).active
      };
      const history = mine.slice(-10).map(m => ({ role: m.who === "owner" ? "user" : "assistant", content: m.text }));
      try {
        const r = await this.callAgentModel(agent, [{
          role: "system",
          content: agent.systemPrompt + "\n\nأنت الآن في محادثة مباشرة مع مالك الشركة داخل مكتبه (أو من محطة عملك). تحدث بصفتك المهنية وبالاستناد فقط إلى السياق الحقيقي المرفق. لا تدّعِ أنك نفذت عملًا غير موثق. إن طلب منك عملًا جديدًا قابلًا للتنفيذ، اشرح أن الأهداف الرسمية تمر عبر الرئيس التنفيذي زياد لتتحول لمشروع ومهمة موثقة، وقدم له ملخصًا أو إجابة ضمن خبرتك إن كان سؤالًا. كن دقيقًا وموجزًا نسبيًا.\n\nسياقك الحقيقي الآن (JSON):\n" + JSON.stringify(context).slice(0, 7500)
        }, ...history], { runType: "agent_chat", maxTokens: 1800, temperature: 0.55, background: false });
        const reply = { id: uid(), who: "agent", agentId: agent.id, text: r.text, at: now(), runId: r.run.id, model: agent.model };
        mine.push(reply);
        if (mine.length > 100) mine.splice(0, mine.length - 100);
        this.activity("محادثة وكيل", "💬 تحدث المالك مباشرة مع " + agent.name + " ورد نموذجه " + agent.model + " (تشغيل " + r.run.id + ").");
        this.persist();
        return this.json(reply);
      } catch (e) {
        this.persist();
        return this.json({ error: "تعذّر على نموذج " + agent.name + " الرد: " + String(e.message || e).slice(0, 320) }, 502);
      }
    }

    if (p === "/api/agents/bulk-assign" && method === "POST") {
      const b = await this.readJson(request);
      const conn = this.connById(b.connectionId);
      if (!conn) return this.json({ error: "اتصال غير صالح" }, 400);
      const targets = this.db.agents.filter(a =>
        b.scope === "all" ? true : b.scope === "employees" ? !a.isCeo : (b.agentIds || []).includes(a.id)
      );
      targets.forEach(a => { a.connectionId = conn.id; a.model = b.model || null; });
      this.activity("تهيئة", "⚙️ تعيين جماعي: " + targets.length + " وكيلًا على " + conn.name + " / " + b.model + ".");
      this.persist();
      return this.json({ ok: true, count: targets.length });
    }

    /* الأهداف والمشاريع والمهام */
    if (p === "/api/goals" && method === "POST") {
      const b = await this.readJson(request);
      const goal = String(b.goal || "").trim();
      if (goal.length < 4) return this.json({ error: "اكتب هدفًا واضحًا" }, 400);
      const project = {
        id: uid(), title: goal.slice(0, 90), goal, origin: "owner",
        status: this.isConfigured(this.ceo()) ? "planning" : "waiting_ceo_config", createdAt: now()
      };
      this.db.projects.push(project);
      this.activity("هدف", "🎯 هدف جديد من المالك: «" + project.title + "»" +
        (project.status === "planning" ? " — المدير زياد سيخطط له في استيقاظ الحلقة التالي." : " — بانتظار تهيئة نموذج للمدير كي يخطط."), { projectId: project.id });
      if (project.status !== "planning") this.resourceRequest("ceo", "هدف بانتظار تهيئة الرئيس التنفيذي زياد", "«" + project.title + "» لن يُخطط حتى يُربط نموذج بالمدير.");
      this.persist();
      return this.json(project, 201);
    }

    const mProject = p.match(/^\/api\/projects\/([\w-]+)\/(cancel|replan)$/);
    if (mProject && method === "POST") {
      const project = this.projById(mProject[1]);
      if (!project) return this.json({ error: "غير موجود" }, 404);
      if (mProject[2] === "cancel") {
        project.status = "cancelled";
        this.db.tasks.forEach(t => {
          if (t.projectId === project.id && ["queued", "blocked_unconfigured"].includes(t.status)) t.status = "cancelled";
        });
        this.activity("مشروع", "ألغى المالك مشروع «" + project.title + "».", { projectId: project.id });
      } else {
        project.status = this.isConfigured(this.ceo()) ? "planning" : "waiting_ceo_config";
        project.planError = null;
        project.planMessages = null;
        project.planAttempt = 0;
        project.planErrorCount = 0;
        project.planNextRetryAt = 0;
        this.activity("مشروع", "طلب المالك إعادة تخطيط «" + project.title + "».", { projectId: project.id });
      }
      this.persist();
      return this.json(project);
    }

    const mTask = p.match(/^\/api\/tasks\/([\w-]+)\/(retry|cancel)$/);
    if (mTask && method === "POST") {
      const task = this.taskById(mTask[1]);
      if (!task) return this.json({ error: "غير موجود" }, 404);
      if (mTask[2] === "retry") {
        task.status = "queued";
        task.attempts = 0;
        task.rateWaits = 0;
        task.revisionCount = 0;
        task.nextRetryAt = 0;
        task.checkpointRunId = null;
        task.currentRunId = null;
        task.reviewMessages = null;
        task.reviewAttempt = 0;
        task.lastAction = "أعادها المالك للطابور يدويًا";
        const project = this.projById(task.projectId);
        if (project && project.status !== "active" && project.status !== "cancelled") project.status = "active";
      } else task.status = "cancelled";
      this.activity("مهمة", (mTask[2] === "retry" ? "أعاد المالك تشغيل" : "ألغى المالك") + " مهمة «" + task.title + "».", { taskId: task.id });
      this.persist();
      return this.json(task);
    }

    /* الرئيس التنفيذي زياد */
    if (p === "/api/ceo/chat" && method === "POST") {
      const boss = this.ceo();
      if (!this.isConfigured(boss)) return this.json({ error: "الرئيس التنفيذي زياد غير مهيأ بنموذج بعد. افتح قسم «اتصالات الذكاء» واربط له نموذجًا — لن أتظاهر برد منه.", code: "CEO_UNCONFIGURED" }, 409);
      const b = await this.readJson(request);
      const msg = String(b.message || "").trim();
      if (!msg) return this.json({ error: "رسالة فارغة" }, 400);
      this.db.ceoChat.push({ id: uid(), who: "owner", text: msg, at: now() });
      const history = this.db.ceoChat.slice(-10).map(m => ({ role: m.who === "owner" ? "user" : "assistant", content: m.text }));
      try {
        const r = await this.callAgentModel(boss, [{
          role: "system",
          content: boss.systemPrompt + "\nأنت تتحدث الآن مع مالك الشركة. كن تنفيذيًا ودقيقًا ومستندًا إلى حالة الشركة الحقيقية المرفقة فقط. إن طلب هدفًا جديدًا أخبره أن يضعه في خانة «تكليف بهدف» ليتحول لمشروع مخطط، ولخص كيف ستخطط له.\nحالة الشركة الآن (JSON حقيقي):\n" + JSON.stringify(this.companyDigest()).slice(0, 3500)
        }, ...history], { runType: "ceo_chat", maxTokens: 2200, background: false });
        const reply = { id: uid(), who: "ceo", text: r.text, at: now(), runId: r.run.id, model: boss.model };
        this.db.ceoChat.push(reply);
        this.persist();
        return this.json(reply);
      } catch (e) {
        this.persist();
        return this.json({ error: "تعذّر على نموذج المدير التنفيذي الرد: " + String(e.message || e).slice(0, 300) }, 502);
      }
    }

    if (p === "/api/ceo/scan" && method === "POST") {
      if (!this.isConfigured(this.ceo())) return this.json({ error: "الرئيس التنفيذي زياد غير مهيأ" }, 409);
      this.db.loop.forceScan = true;
      this.activity("مسح المدير", "طلب المالك مسحًا فوريًا من المدير زياد؛ سيُنفذ في استيقاظ الحلقة التالي.");
      this.persist();
      return this.json({ ok: true, note: "جُدول مسح المدير — قراراته ستظهر في النشاط والقرارات" }, 202);
    }

    /* اجتماعات وموافقات وإعدادات */
    if (p === "/api/meetings" && method === "POST") {
      const b = await this.readJson(request);
      const result = this.createMeeting(b.type === "أسبوعي" ? "أسبوعي" : "طارئ", "المالك");
      if (result.error) return this.json({ error: result.error }, 409);
      return this.json(result.meeting, 201);
    }

    const mApproval = p.match(/^\/api\/approvals\/([\w-]+)\/decide$/);
    if (mApproval && method === "POST") {
      const approval = this.db.approvals.find(x => x.id === mApproval[1]);
      if (!approval || approval.status !== "pending") return this.json({ error: "غير موجود أو حُسم" }, 404);
      const b = await this.readJson(request);
      approval.decidedAt = now();
      if (!b.approve) {
        approval.status = "rejected";
        this.activity("موافقة", "رفض المالك: " + approval.title);
      } else if (approval.type === "improvement") {
        approval.status = "approved";
        const project = {
          id: uid(), title: "تنفيذ تحسين: " + approval.title.slice(0, 70),
          goal: "تنفيذ مقترح تحسين معتمد من المالك: " + approval.title + " — " + approval.details,
          origin: "improvement", status: this.isConfigured(this.ceo()) ? "planning" : "waiting_ceo_config", createdAt: now()
        };
        this.db.projects.push(project);
        this.activity("موافقة", "✅ وافق المالك على التحسين «" + approval.title + "» وسيُنفذ كمشروع حقيقي.", { projectId: project.id });
      } else if (approval.type === "task_failed" && approval.meta?.taskId) {
        approval.status = "approved";
        const task = this.taskById(approval.meta.taskId);
        if (task) {
          task.status = "queued";
          task.attempts = 0;
          task.rateWaits = 0;
          task.revisionCount = 0;
          task.nextRetryAt = 0;
          task.checkpointRunId = null;
          task.currentRunId = null;
          const project = this.projById(task.projectId);
          if (project && project.status !== "cancelled") project.status = "active";
        }
        this.activity("موافقة", "✅ قرر المالك إعادة تشغيل المهمة المتعثرة: " + approval.title);
      } else {
        approval.status = "acknowledged";
        this.activity("موافقة", "اطّلع المالك واعتمد المتابعة: " + approval.title);
      }
      this.persist();
      return this.json(approval);
    }

    if (p === "/api/settings" && method === "PUT") {
      const b = await this.readJson(request);
      if (b.companyName) this.db.company.name = String(b.companyName).slice(0, 60);
      for (const key of ["maxSteps", "maxTasksPerProject", "concurrency"]) {
        if (b[key] !== undefined) this.db.settings[key] = Math.max(1, Math.min(20, parseInt(b[key]) || this.db.settings[key]));
      }
      if (b.autonomy) this.db.settings.autonomy = { ...this.db.settings.autonomy, ...b.autonomy };
      if (typeof b.weeklyMeetings === "boolean") this.db.settings.weeklyMeetings = b.weeklyMeetings;
      this.activity("إعدادات", "حدّث المالك إعدادات الشركة.");
      this.persist();
      return this.json(this.db.settings);
    }

    /* المستندات */
    const mArtifact = p.match(/^\/api\/artifacts\/([\w-]+)(\/raw)?$/);
    if (mArtifact && method === "GET") {
      const artifact = this.db.artifacts.find(x => x.id === mArtifact[1]);
      if (!artifact) return this.json({ error: "غير موجود" }, 404);
      if (mArtifact[2]) {
        const bytes = this.artifactBytes(artifact);
        if (bytes) {
          return new Response(bytes, {
            status: 200,
            headers: {
              "Content-Type": artifact.mime || "application/octet-stream",
              "Content-Disposition": "inline; filename*=UTF-8''" + encodeURIComponent(artifact.title + "." + artifact.ext),
              ...CORS
            }
          });
        }
        if (artifact.meta?.cloudinaryUrl) {
          const redirect = Response.redirect(artifact.meta.cloudinaryUrl, 302);
          const headers = new Headers(redirect.headers);
          for (const [k, v] of Object.entries(CORS)) headers.set(k, v);
          return new Response(null, { status: 302, headers });
        }
        return this.json({ error: "الملف غير موجود في SQLite أو Cloudinary" }, 404);
      }
      return this.json({ ...artifact, content: artifact.kind === "text" ? this.artifactText(artifact) : null });
    }

    if (p === "/api/cloudinary/sign" && method === "POST") {
      const c = this.cloudinaryConfig();
      if (!c) return this.json({ error: "Cloudinary غير مضبوط على Cloudflare (CLOUDINARY_*). المخرجات تُحفظ في Durable Object SQLite لحين ضبطه." }, 501);
      const b = await this.readJson(request);
      const timestamp = Math.floor(Date.now() / 1000);
      const folder = b.folder || "ai-company";
      const signature = await this.secretBox.sha1Hex(`folder=${folder}&timestamp=${timestamp}${c.apiSecret}`);
      return this.json({
        cloudName: c.cloudName, apiKey: c.apiKey, timestamp, folder, signature,
        uploadUrl: `https://api.cloudinary.com/v1_1/${c.cloudName}/auto/upload`
      });
    }

    if (p === "/api/backup" && method === "GET") {
      const copy = JSON.parse(JSON.stringify(this.db));
      copy.connections = copy.connections.map(c => this.safeConn(c));
      copy.runs.forEach(r => { delete r.messages; delete r.finalText; });
      copy.projects.forEach(x => { delete x.planMessages; });
      copy.tasks.forEach(x => { delete x.reviewMessages; });
      return this.json(copy);
    }

    return this.json({ error: "مسار غير موجود" }, 404);
  }
}
