/**
 * أدوات الوكلاء في Cloudflare Workers. كل أداة طلب فعلي أو بحث فعلي في أرشيف الشركة.
 * لا توجد أداة js_sandbox هنا لأن Workers لا تشغّل Node vm ولا تسمح بتقييم كود ديناميكي بنفس الطريقة.
 */
export const TOOL_DEFS = [
  { id: "web_search", name: "بحث الويب", desc: "البحث على الويب عبر DuckDuckGo. الوسائط: {\"query\":\"نص البحث\"}. تعيد عناوين وروابط ومقتطفات حقيقية." },
  { id: "web_fetch", name: "جلب صفحة ويب", desc: "جلب نص صفحة من رابط. الوسائط: {\"url\":\"https://...\"}." },
  { id: "docs_search", name: "بحث في مستندات الشركة", desc: "البحث في مخرجات الشركة المحفوظة سابقًا. الوسائط: {\"query\":\"كلمات\"}. تعيد مقتطفات مع معرفات المستندات." },
  { id: "image_generate", name: "توليد صورة", desc: "توليد صورة فعليًا بنموذج صور وحفظها كمستند بالشركة. الوسائط: {\"prompt\":\"وصف تفصيلي بالإنجليزية\",\"width\":1024,\"height\":1024}. تعيد معرف الصورة المحفوظة." }
];

function stripHtml(html) {
  return String(html || "")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, "\"")
    .replace(/&#x27;|&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

async function timedFetch(url, opts = {}, timeoutMs = 30000) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  try { return await fetch(url, { ...opts, signal: ctl.signal }); }
  finally { clearTimeout(timer); }
}

function decodeBingUrl(enc) {
  try {
    const binary = atob(enc.slice(2));
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return new TextDecoder().decode(bytes);
  } catch { return enc; }
}

function cleanUrl(href, baseUrl) {
  try {
    const u = new URL(String(href).replace(/&amp;/g, "&"), baseUrl);
    const uddg = u.searchParams.get("uddg");
    if (uddg) return uddg;
    const enc = u.searchParams.get("u");
    if (enc && enc.startsWith("a1")) return decodeBingUrl(enc);
    return u.href;
  } catch { return href; }
}

async function webSearch(query) {
  if (!String(query || "").trim()) throw new Error("query مطلوب");
  const headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36",
    "Accept-Language": "ar,en;q=0.8"
  };

  try {
    const r = await timedFetch("https://html.duckduckgo.com/html/?q=" + encodeURIComponent(query), { headers });
    if (r.ok) {
      const html = await r.text();
      const links = [...html.matchAll(/<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g)];
      const snips = [...html.matchAll(/class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g)];
      const out = links.slice(0, 6).map((m, i) =>
        (i + 1) + ". " + stripHtml(m[2]) + "\n   " + cleanUrl(m[1], "https://duckduckgo.com") +
        (snips[i] ? "\n   " + stripHtml(snips[i][1]).slice(0, 240) : "")
      );
      if (out.length) return { text: "نتائج ويب حقيقية (عبر DuckDuckGo) عن «" + query + "»:\n" + out.join("\n") };
    }
  } catch {}

  try {
    const r = await timedFetch("https://www.bing.com/search?q=" + encodeURIComponent(query) + "&count=8", { headers });
    if (r.ok) {
      const html = await r.text();
      const chunks = html.split("class=\"b_algo\"").slice(1, 9);
      const out = [];
      for (const ch of chunks) {
        const a = ch.match(/<h2>[\s\S]*?<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/);
        if (!a) continue;
        const sn = ch.match(/<p[^>]*>([\s\S]*?)<\/p>/);
        out.push((out.length + 1) + ". " + stripHtml(a[2]) + "\n   " + cleanUrl(a[1], "https://www.bing.com") + (sn ? "\n   " + stripHtml(sn[1]).slice(0, 240) : ""));
        if (out.length >= 6) break;
      }
      if (out.length) return { text: "نتائج ويب حقيقية (عبر Bing) عن «" + query + "»:\n" + out.join("\n") };
    }
  } catch {}

  throw new Error("محركا بحث الويب لم يعودا بنتائج قابلة للقراءة الآن (حظر آلي مؤقت من مزودي البحث)");
}

function assertPublicHttpUrl(rawUrl) {
  const u = new URL(rawUrl);
  if (!/^https?:$/.test(u.protocol)) throw new Error("يسمح فقط بروابط http/https");
  const host = u.hostname.toLowerCase();
  if (
    host === "localhost" || host.endsWith(".local") || host === "127.0.0.1" || host === "0.0.0.0" || host === "::1" ||
    /^10\./.test(host) || /^192\.168\./.test(host) || /^172\.(1[6-9]|2\d|3[01])\./.test(host) || /^169\.254\./.test(host)
  ) throw new Error("لا يسمح بجلب عناوين خاصة أو محلية من السحابة");
  return u;
}

async function webFetch(rawUrl) {
  const u = assertPublicHttpUrl(rawUrl);
  const r = await timedFetch(u, { headers: { "User-Agent": "Mozilla/5.0" }, redirect: "follow" }, 30000);
  if (!r.ok) throw new Error("الموقع رد بـ " + r.status);
  const text = stripHtml(await r.text()).slice(0, 4200);
  if (!text) throw new Error("الصفحة بلا نص قابل للقراءة");
  return { text: "نص الصفحة " + rawUrl + ":\n" + text };
}

function docsSearch(query, ctx) {
  const terms = String(query || "").toLowerCase().split(/\s+/).filter(t => t.length > 2);
  const hits = [];
  for (const a of ctx.db.artifacts || []) {
    let score = 0;
    const title = String(a.title || "").toLowerCase();
    terms.forEach(t => { if (title.includes(t)) score += 3; });
    let excerpt = "";
    if (a.kind === "text") {
      const content = ctx.getArtifactText(a) || "";
      const low = content.toLowerCase();
      terms.forEach(t => { if (low.includes(t)) score += 1; });
      excerpt = content.slice(0, 500);
    }
    if (score > 0) hits.push({ a, score, excerpt });
  }
  hits.sort((x, y) => y.score - x.score);
  if (!hits.length) return { text: "لا مستندات مطابقة في أرشيف الشركة عن «" + query + "»." };
  return {
    text: hits.slice(0, 4).map(h => "📄 [" + h.a.id + "] " + h.a.title + (h.excerpt ? "\n" + h.excerpt + "…" : "")).join("\n\n")
  };
}

async function imageGenerate(args, ctx) {
  const prompt = String(args.prompt || "").trim();
  if (!prompt) throw new Error("prompt مطلوب");
  const w = Math.min(1280, Math.max(256, parseInt(args.width) || 1024));
  const h = Math.min(1280, Math.max(256, parseInt(args.height) || 1024));
  const url = "https://image.pollinations.ai/prompt/" + encodeURIComponent(prompt) +
    `?width=${w}&height=${h}&nologo=true&seed=${Math.floor(Math.random() * 99999)}`;
  const r = await timedFetch(url, { headers: { "User-Agent": "Mozilla/5.0" } }, 120000);
  if (!r.ok) throw new Error("خدمة الصور ردت بـ " + r.status);
  const bytes = new Uint8Array(await r.arrayBuffer());
  if (bytes.length < 2000) throw new Error("الخدمة أعادت ملفًا غير صالح");
  const art = await ctx.saveArtifact({
    kind: "image",
    title: "صورة مولّدة: " + prompt.slice(0, 70),
    ext: "jpg",
    data: bytes,
    mime: "image/jpeg",
    meta: { prompt, width: w, height: h, generator: "image.pollinations.ai" }
  });
  return {
    text: "تم توليد صورة فعليًا وحفظها كمستند رقم " + art.id + " بعنوان «" + art.title + "». اذكر هذا المعرف في تسليمك.",
    artifactIds: [art.id]
  };
}

export async function executeTool(toolId, args, ctx) {
  args = args || {};
  switch (toolId) {
    case "web_search": return webSearch(String(args.query || ""));
    case "web_fetch": return webFetch(String(args.url || ""));
    case "docs_search": return docsSearch(String(args.query || ""), ctx);
    case "image_generate": return imageGenerate(args, ctx);
    case "js_sandbox": throw new Error("أداة تنفيذ JavaScript المعزول غير متاحة في نسخة Cloudflare؛ لا يمكن ادّعاء تنفيذ الكود هنا");
    default: throw new Error("أداة غير معروفة: " + toolId);
  }
}
