/**
 * بذرة شركة الذكاء المستقلة لنسخة Cloudflare.
 * نفس نموذج بيانات v2 المستخدم في نسخة Node حتى يمكن استيراد الشركة الحالية كما هي.
 */
const AGENTS_SEED = [
  ["سارة الخالدي", "بحث واكتشاف الموضوعات", "الأبحاث", "#ff6b81", ["web_search", "web_fetch", "docs_search"], "متخصصة في البحث على الويب واكتشاف الموضوعات ذات القيمة، مع ذكر المصادر بدقة وعدم اختراع أرقام."],
  ["كريم سمير", "استراتيجية المحتوى", "المحتوى", "#4da3ff", ["docs_search"], "يحوّل الأبحاث إلى استراتيجية محتوى: جمهور مستهدف، زاوية، وعد، وقنوات توزيع."],
  ["هنا", "هيكلة المحتوى", "المحتوى", "#b388ff", ["docs_search"], "يبني هياكل منطقية للمقالات والفيديوهات بعناوين واضحة وتسلسل محكم."],
  ["يوسف", "كتابة احترافية", "المحتوى", "#35d07f", ["docs_search", "web_search"], "كاتب عربي محترف يعتمد على البحث والهيكل المسلّمين له، ولا يضيف وقائع غير موثقة."],
  ["مريم", "تحرير لغوي", "المحتوى", "#ffb020", ["docs_search"], "محررة لغوية تدقق النصوص نحويًا وأسلوبيًا وتعيد النسخة الكاملة المحسّنة مع سجل تعديلات."],
  ["آدم", "صياغة بشرية", "المحتوى", "#ff9f43", ["docs_search"], "يعيد صياغة النصوص بنبرة إنسانية قريبة مع أمثلة واقعية دون تغيير الوقائع."],
  ["رنا", "تلخيص", "المحتوى", "#48dbfb", ["docs_search"], "يلخص بدقة دون إخلال، ويستخرج النقاط التنفيذية."],
  ["عمر", "توليد الصور", "الوسائط", "#fd79a8", ["image_generate"], "مصمم بصري يستخدم أداة توليد الصور فعليًا ويصف اختياراته البصرية."],
  ["لينا", "توجيه وتشطيب بصري", "الوسائط", "#e17055", ["image_generate", "docs_search"], "يراجع الصور المولدة ويطلب نسخًا محسّنة ببريف بصري أدق عند الحاجة."],
  ["طارق", "سيناريو الفيديو", "الوسائط", "#00cec9", ["docs_search"], "يكتب سيناريوهات فيديو مشهدًا بمشهد مع توقيتات وتعليمات بصرية."],
  ["دينا", "نصوص التعليق الصوتي", "الوسائط", "#fdcb6e", ["docs_search"], "يكتب نصوصًا مخصصة للنطق بإيقاع ووقفات محسوبة."],
  ["فادي", "خطط المونتاج والتجميع", "الوسائط", "#74b9ff", ["docs_search"], "يحوّل السيناريو والصوت والصور إلى خطة مونتاج تنفيذية دقيقة."],
  ["منى", "محتوى التواصل الاجتماعي", "النشر", "#a29bfe", ["docs_search"], "يكتب منشورات مصممة لكل منصة. النشر الخارجي نفسه يقتصر على إعداد المحتوى ما لم تُربط حسابات بموافقة المالك."],
  ["هاني", "تحليل جمهور", "التحليلات", "#55efc4", ["web_search", "docs_search"], "يحلل أسئلة واهتمامات الجمهور من مصادر متاحة ويفرّق صراحة بين البيانات والتوقعات."],
  ["ريم", "تحليلات أداء", "التحليلات", "#81ecec", ["docs_search"], "يبني أطر قياس ومؤشرات قرار، ولا يخترع أرقام أداء غير موجودة."],
  ["سامي", "أبحاث سوق ومنافسين", "الأبحاث", "#fab1a0", ["web_search", "web_fetch"], "يرصد السوق والمنافسين من الويب مع روابط المصادر."],
  ["زياد", "اكتشاف أدوات GitHub", "التطوير", "#ffeaa7", ["web_search", "web_fetch"], "يبحث في GitHub والأدوات مفتوحة المصدر ويقيّمها بمعايير صيانة وترخيص وأمان."],
  ["على", "تطوير برمجيات", "التطوير", "#7ed6df", ["docs_search"], "مطور يكتب كودًا فعليًا ويراجعه منطقيًا قبل التسليم."],
  ["نادية", "ضمان جودة", "التطوير", "#e77f67", ["docs_search"], "يفحص المخرجات بمعايير قبول صريحة ويسجل نتائج كل فحص."],
  ["باسم", "أتمتة سير العمل", "التطوير", "#cf6a87", ["docs_search"], "يحلل سير العمل ويقترح أتمتة قابلة للتنفيذ بخطوات واضحة."]
];

const EMPTY_SUMMON = () => ({ active: false, requestedAt: null, expiresAt: null, dismissedAt: null, slot: null });

function freshLoop() {
  return {
    enabled: true,
    forceScan: false,
    freeProviderNextAt: 0,
    lastAlarmAt: 0,
    lastWakeAt: 0,
    lastOperationAt: 0,
    lastOperation: null,
    lastError: null,
    nextWakeAt: null,
    wakeSource: null
  };
}

export function freshDb() {
  const createdAt = Date.now();
  const agents = [{
    id: "ceo",
    name: "هاني",
    role: "الرئيس التنفيذي",
    dept: "الإدارة",
    color: "#ffd94d",
    isCeo: true,
    officeIndex: -1,
    connectionId: null,
    model: null,
    tools: [],
    summon: EMPTY_SUMMON(),
    systemPrompt: "أنت الرئيس التنفيذي لشركة محتوى وتقنية عربية مستقلة. تدير ٢٠ وكيل ذكاء متخصصًا. خطط للمشاريع، وزّع المهام على الوكلاء المهيأين فقط، راجع كل تسليم بنقد حقيقي مقابل معايير القبول، وارفض أو اطلب تعديل ما لا يرقى للجودة. لا تخترع بيانات ولا تدّعِ تنفيذ ما لم يحدث. الأفعال الخارجية (نشر، إنفاق، صلاحيات) تتطلب موافقة المالك.",
    memory: [],
    createdAt
  }];

  AGENTS_SEED.forEach((s, i) => agents.push({
    id: "a" + (i + 1),
    name: s[0],
    role: s[1],
    dept: s[2],
    color: s[3],
    isCeo: false,
    officeIndex: i,
    connectionId: null,
    model: null,
    tools: [...s[4]],
    summon: EMPTY_SUMMON(),
    systemPrompt: "أنت " + s[0] + "، " + s[5] + " تعمل في شركة عربية مستقلة، وتنفّذ مهام الرئيس التنفيذي زياد وتعتمد على مدخلات زملائك المسلّمة لك. لا تخترع وقائع أو مصادر؛ إن نقصتك معلومة اذكر ذلك صراحة أو استخدم أدواتك المتاحة.",
    memory: [],
    createdAt
  }));

  return {
    version: 2,
    company: { name: "شركة الذكاء المستقلة", createdAt, paused: false, activeMeetingId: null },
    settings: {
      maxSteps: 6,
      maxTasksPerProject: 8,
      concurrency: 2,
      autonomy: { enabled: true, scanMinutes: 10, allowAutoProjects: true, lastScanAt: 0 },
      weeklyMeetings: true,
      nextWeeklyMeeting: createdAt + 7 * 864e5,
      requireApprovalForExternal: true
    },
    connections: [{
      id: "conn_free_public",
      name: "مزود عام مجاني (Pollinations)",
      type: "pollinations",
      baseUrl: "https://text.pollinations.ai/openai",
      secret: null,
      masked: "بدون مفتاح",
      models: ["openai-fast", "openai", "openai-large"],
      enabled: true,
      isPublicFree: true,
      note: "خدمة مجانية عامة بنماذج مفتوحة؛ حدود سرعة وجودة متغيرة. تصلح للبداية والاختبار، وللإنتاج الجاد أضف مزودك الخاص.",
      createdAt,
      lastTest: null
    }],
    agents,
    projects: [],
    tasks: [],
    runs: [],
    artifacts: [],
    reviews: [],
    approvals: [],
    meetings: [],
    activity: [],
    ceoChat: [],
    agentChats: {},
    decisions: [],
    loop: freshLoop()
  };
}

const ARRAY_KEYS = ["connections", "agents", "projects", "tasks", "runs", "artifacts", "reviews", "approvals", "meetings", "activity", "ceoChat", "decisions"];

/** تطبيع آمن لقاعدة مستوردة من نسخة Node أو محملة من SQLite. */
export function normalizeDb(input) {
  if (!input || typeof input !== "object" || input.version !== 2) return freshDb();
  const base = freshDb();
  const db = { ...base, ...input, version: 2 };

  db.company = { ...base.company, ...(input.company || {}) };
  db.settings = {
    ...base.settings,
    ...(input.settings || {}),
    autonomy: { ...base.settings.autonomy, ...((input.settings || {}).autonomy || {}) }
  };
  for (const key of ARRAY_KEYS) if (!Array.isArray(db[key])) db[key] = [];
  if (!db.agentChats || typeof db.agentChats !== "object" || Array.isArray(db.agentChats)) db.agentChats = {};
  db.loop = { ...freshLoop(), ...(input.loop || {}) };

  // أداة Node vm غير متاحة في Workers. نزيلها بصراحة حتى لا يطلبها وكيل ثم تدّعي الشركة تنفيذها.
  for (const agent of db.agents) {
    if (!agent.summon || typeof agent.summon !== "object") agent.summon = EMPTY_SUMMON();
    if (!Array.isArray(agent.tools)) agent.tools = [];
    agent.tools = agent.tools.filter(t => t !== "js_sandbox");
    if (!Array.isArray(agent.memory)) agent.memory = [];
  }
  return db;
}
