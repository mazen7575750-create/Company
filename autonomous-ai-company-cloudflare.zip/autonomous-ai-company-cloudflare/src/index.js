import { DurableObject } from "cloudflare:workers";
import { DurableStore } from "./store.js";
import { CompanyEngine } from "./engine.js";

const COMPANY_INSTANCE = "autonomous-ai-company-main";

export class CompanyDurableObject extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.store = new DurableStore(ctx);
    this.engine = new CompanyEngine({
      store: this.store,
      env,
      setAlarm: timestamp => ctx.storage.setAlarm(timestamp),
      getAlarm: () => ctx.storage.getAlarm(),
      deleteAlarm: () => ctx.storage.deleteAlarm()
    });
  }

  async fetch(request) {
    return this.engine.handleFetch(request);
  }

  async alarm() {
    await this.engine.handleAlarm();
  }
}

function companyStub(env) {
  const id = env.COMPANY.idFromName(COMPANY_INSTANCE);
  return env.COMPANY.get(id);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) {
      return companyStub(env).fetch(request);
    }
    if (env.ASSETS) return env.ASSETS.fetch(request);
    return new Response("شركة الذكاء المستقلة — ملفات الواجهة غير موجودة في هذا النشر", {
      status: 404,
      headers: { "Content-Type": "text/plain; charset=utf-8" }
    });
  },

  async scheduled(controller, env, ctx) {
    // Cron احتياطي فقط: القلب الأساسي منبّه Durable Object نفسه.
    ctx.waitUntil((async () => {
      const response = await companyStub(env).fetch("https://company.internal/__loop/wake", {
        method: "POST",
        headers: {
          "x-loop-source": "cloudflare-cron",
          "x-loop-secret": env.LOOP_WAKE_SECRET || ""
        }
      });
      if (!response.ok) console.warn("Cron wake returned", response.status, await response.text().catch(() => ""));
    })());
  }
};
