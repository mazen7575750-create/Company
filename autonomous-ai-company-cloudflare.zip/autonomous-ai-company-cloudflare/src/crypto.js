const encoder = new TextEncoder();
const decoder = new TextDecoder();

export function bytesToBase64(bytes) {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < u8.length; i += chunk) binary += String.fromCharCode(...u8.subarray(i, i + chunk));
  return btoa(binary);
}

export function base64ToBytes(value) {
  const binary = atob(String(value || ""));
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}

function concatBytes(a, b) {
  const out = new Uint8Array(a.length + b.length);
  out.set(a, 0);
  out.set(b, a.length);
  return out;
}

async function shaHex(algorithm, text) {
  const digest = await crypto.subtle.digest(algorithm, encoder.encode(String(text)));
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, "0")).join("");
}

/**
 * متوافق مع صيغة Node الحالية {iv, tag, ct}: WebCrypto يتعامل مع ct+tag ككتلة واحدة،
 * لذلك نفصل آخر 16 بايت عند التشفير ونعيد ضمها عند فك تشفير بيانات مستوردة.
 */
export class SecretBox {
  constructor(secret) {
    this.secret = String(secret || "dev-only");
    this._keyPromise = null;
  }

  async key() {
    if (!this._keyPromise) {
      this._keyPromise = (async () => {
        const material = await crypto.subtle.digest("SHA-256", encoder.encode(this.secret));
        return crypto.subtle.importKey("raw", material, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
      })();
    }
    return this._keyPromise;
  }

  async encrypt(value) {
    if (!value) return null;
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const sealed = new Uint8Array(await crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      await this.key(),
      encoder.encode(String(value))
    ));
    if (sealed.length < 17) throw new Error("ناتج تشفير غير صالح");
    const ct = sealed.subarray(0, sealed.length - 16);
    const tag = sealed.subarray(sealed.length - 16);
    return { iv: bytesToBase64(iv), tag: bytesToBase64(tag), ct: bytesToBase64(ct) };
  }

  async decrypt(record) {
    if (!record) return null;
    const iv = base64ToBytes(record.iv);
    const sealed = concatBytes(base64ToBytes(record.ct), base64ToBytes(record.tag));
    const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, await this.key(), sealed);
    return decoder.decode(plain);
  }

  sha1Hex(text) { return shaHex("SHA-1", text); }
  sha256Hex(text) { return shaHex("SHA-256", text); }
}

export const maskSecret = value => value ? String(value).slice(0, 3) + "••••••" + String(value).slice(-4) : "بدون مفتاح";
