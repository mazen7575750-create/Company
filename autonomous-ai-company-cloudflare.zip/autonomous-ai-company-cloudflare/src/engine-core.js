import { SecretBox, maskSecret } from "./crypto.js";
import { PROVIDER_TYPES, chat, listModels } from "./providers.js";
import { TOOL_DEFS, executeTool } from "./tools.js";
import { normalizeDb } from "./seed.js";

const now = () => Date.now();
const uid = () => "x" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const sleep = ms => new Promise(resolve => setTimeout(resolve, Math.max(0, ms)));

export class CompanyCore {
  constructor({ store, env = {}, setAlarm = null, getAlarm = null, deleteAlarm = null }) {
    this.store = store;
    this.env = env;
    this.db = store.load();
    this.setAlarmFn = setAlarm;
    this.getAlarmFn = getAlarm;
    this.deleteAlarmFn = deleteAlarm;
    this.ownerToken = env.OWNER_TOKEN || "";
    this.encryptionConfigured = !!String(env.ENCRYPTION_SECRET || "").trim();
    this.secretBox = new SecretBox(env.ENCRYPTION_SECRET || this.ownerToken || "dev-only");
    this._tail = Promise.resolve();
    this._meetingBusy = false;
    this._scanBusy = false;
    if (!this.db.loop) this.db.loop = {};
  }

  /* ---------- قفل تسلسلي وحفظ ---------- */
  withLock(fn) {
    const run = async () => {
      this.db = this.store.load();
      try { return await fn(); }
      finally { this.store.flush(); }
    };
    const result = this._tail.then(run, run);
    this._tail = result.catch(() => {});
    return result;
  }

  persist() { this.store.saveNow(); this.db = this.store.db; }
  mark() { this.store.save(); }

  activity(type, text, meta = {}) {
    this.db.activity.push({ id: uid(), ts: now(), type, text, ...meta });
    if (this.db.activity.length > 2000) this.db.activity.splice(0, this.db.activity.length - 2000);
    this.mark();
  }

  /* ---------- كيانات مساعدة ---------- */
  agentById(id) { return this.db.agents.find(a => a.id === id); }
  taskById(id) { return this.db.tasks.find(t => t.id === id); }
  projById(id) { return this.db.projects.find(p => p.id === id); }
  connById(id) { return this.db.connections.find(c => c.id === id); }
  runById(id) { return this.db.runs.find(r => r.id === id); }
  ceo() { return this.agentById("ceo"); }

  isConfigured(agent) {
    if (!agent || !agent.model) return false;
    const conn = this.connById(agent.connectionId);
    return !!(conn && conn.enabled);
  }

  async encSecret(value) { return this.secretBox.encrypt(value); }

  async connKey(conn) {
    if (!conn?.secret) return null;
    try { return await this.secretBox.decrypt(conn.secret); }
    catch { return null; }
  }

  safeConn(conn) {
    return {
      id: conn.id, name: conn.name, type: conn.type, baseUrl: conn.baseUrl, masked: conn.masked,
      models: conn.models || [], enabled: conn.enabled, isPublicFree: !!conn.isPublicFree,
      note: conn.note || "", lastTest: conn.lastTest || null, createdAt: conn.createdAt
    };
  }

  resourceRequest(key, title, details) {
    if (this.db.approvals.some(a => a.status === "pending" && a.meta?.key === key)) return;
    this.db.approvals.push({ id: uid(), type: "resource", title, details, status: "pending", createdAt: now(), meta: { key } });
    this.activity("طلب مورد", "🔌 " + title);
    this.mark();
  }

  deliverableToText(d) {
    if (typeof d === "string") return d;
    if (Array.isArray(d)) return d.map((item, i) => {
      if (item && typeof item === "object") {
        return (i + 1) + ".\n" + Object.entries(item).map(([k, v]) =>
          "   - " + k + ": " + (typeof v === "object" ? JSON.stringify(v) : String(v))
        ).join("\n");
      }
      return (i + 1) + ". " + String(item);
    }).join("\n\n");
    if (d && typeof d === "object") {
      return Object.entries(d).map(([k, v]) =>
        k + ": " + (typeof v === "object" ? JSON.stringify(v, null, 1) : String(v))
      ).join("\n");
    }
    return String(d ?? "");
  }

  extractJSON(text) {
    if (!text) return null;
    const s = text.indexOf("{"), e = text.lastIndexOf("}");
    if (s < 0 || e <= s) return null;
    const raw = text.slice(s, e + 1);
    try { return JSON.parse(raw); } catch {}
    try { return JSON.parse(raw.replace(/,\s*([}\]])/g, "$1")); } catch { return null; }
  }

  /* ---------- Cloudinary والمستندات ---------- */
  cloudinaryConfig() {
    const cloudName = this.env.CLOUDINARY_CLOUD_NAME;
    const apiKey = this.env.CLOUDINARY_API_KEY;
    const apiSecret = this.env.CLOUDINARY_API_SECRET;
    return cloudName && apiKey && apiSecret ? { cloudName, apiKey, apiSecret } : null;
  }

  async uploadToCloudinary(rec, bytes) {
    const c = this.cloudinaryConfig();
    if (!c) return null;
    const timestamp = Math.floor(Date.now() / 1000);
    const folder = "ai-company/" + (rec.kind === "image" ? "images" : rec.kind === "video" ? "videos" : rec.kind === "text" ? "articles" : "files");
    const publicId = rec.id;
    const signature = await this.secretBox.sha1Hex(
      `folder=${folder}&public_id=${publicId}&timestamp=${timestamp}${c.apiSecret}`
    );
    const form = new FormData();
    form.append("file", new Blob([bytes], { type: rec.mime || "application/octet-stream" }), rec.id + "." + (rec.ext || "bin"));
    form.append("api_key", c.apiKey);
    form.append("timestamp", String(timestamp));
    form.append("folder", folder);
    form.append("public_id", publicId);
    form.append("signature", signature);
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 120000);
    try {
      const r = await fetch(`https://api.cloudinary.com/v1_1/${c.cloudName}/auto/upload`, {
        method: "POST", body: form, signal: ctl.signal
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.secure_url) throw new Error(j.error?.message || ("Cloudinary HTTP " + r.status));
      return {
        cloudinaryUrl: j.secure_url,
        cloudinaryPublicId: j.public_id,
        cloudinaryResourceType: j.resource_type || null
      };
    } finally { clearTimeout(timer); }
  }

  async saveArtifact({ kind, title, ext, data, mime, meta = {}, taskId = null, projectId = null, agentId = null }) {
    const id = uid();
    const bytes = data instanceof Uint8Array ? data : new TextEncoder().encode(String(data ?? ""));
    const rec = {
      id, kind, title, ext,
      mime: mime || (kind === "image" ? "image/jpeg" : "text/markdown"),
      size: bytes.byteLength,
      meta: { ...meta },
      taskId, projectId, agentId,
      createdAt: now(),
      storage: "sqlite"
    };

    const hasCloudinary = !!this.cloudinaryConfig();
    if (kind === "text") {
      // النص مطلوب فورًا لاعتماديات المهام ومراجعة زياد، لذلك الأصل العملي في SQLite وCloudinary نسخة سحابية دائمة.
      this.store.writeArtifact(id, ext, bytes);
      this.db.artifacts.push(rec);
      this.persist();
      if (hasCloudinary) {
        try {
          const uploaded = await this.uploadToCloudinary(rec, bytes);
          rec.meta = { ...rec.meta, ...uploaded };
          rec.storage = "sqlite+cloudinary";
        } catch (e) {
          rec.meta = { ...rec.meta, cloudinaryError: String(e.message || e).slice(0, 240) };
        }
        this.persist();
      }
      return rec;
    }

    // الصور والملفات: Cloudinary هي الأصل عند ضبطها، وSQLite بديل فعلي عند غيابها أو فشل الرفع.
    if (hasCloudinary) {
      try {
        const uploaded = await this.uploadToCloudinary(rec, bytes);
        rec.meta = { ...rec.meta, ...uploaded };
        rec.storage = "cloudinary";
      } catch (e) {
        rec.meta = { ...rec.meta, cloudinaryError: String(e.message || e).slice(0, 240) };
        this.store.writeArtifact(id, ext, bytes);
        rec.storage = "sqlite";
      }
    } else {
      this.store.writeArtifact(id, ext, bytes);
    }
    this.db.artifacts.push(rec);
    this.persist();
    return rec;
  }

  artifactText(record) {
    if (!record || record.kind !== "text") return "";
    return this.store.readArtifactText(record.id) || "";
  }

  artifactBytes(record) {
    if (!record) return null;
    return this.store.readArtifact(record.id);
  }

  /* ---------- بوابة المزود المجاني واستدعاء النموذج ---------- */
  providerReadyAt(agent) {
    const conn = agent ? this.connById(agent.connectionId) : null;
    return conn?.type === "pollinations" ? Number(this.db.loop?.freeProviderNextAt || 0) : 0;
  }

  async rateGate(conn, { background = true } = {}) {
    if (conn?.type !== "pollinations") return;
    const nextAt = Number(this.db.loop.freeProviderNextAt || 0);
    const wait = nextAt - now();
    if (wait > 0) {
      if (background) {
        const e = new Error("نافذة المزود المجاني لم تحن بعد");
        e.code = "PROVIDER_WAIT";
        e.status = 429;
        e.retryAt = nextAt;
        throw e;
      }
      if (wait > 60000) {
        const e = new Error("المزود المجاني في فترة انتظار؛ حاول بعد قليل");
        e.code = "PROVIDER_WAIT";
        e.status = 429;
        e.retryAt = nextAt;
        throw e;
      }
      await sleep(wait);
    }
    this.db.loop.freeProviderNextAt = now() + 46000;
    this.persist();
  }

  isTransientError(err) {
    return err?.code === "PROVIDER_WAIT" || err?.code === "EMPTY_RESPONSE" ||
      [402, 408, 409, 425, 429, 500, 502, 503, 504].includes(Number(err?.status)) ||
      /abort|timeout|fetch|network|FREE_LIMIT|فارغ/i.test(String(err?.message || ""));
  }

  async callAgentModel(agent, messages, {
    runType, taskId = null, projectId = null, maxTokens = 2400,
    temperature = 0.6, existingRun = null, background = true
  } = {}) {
    if (!this.isConfigured(agent)) {
      const e = new Error("الوكيل «" + (agent?.name || "غير معروف") + "» غير مهيأ بنموذج");
      e.code = "UNCONFIGURED";
      throw e;
    }
    const conn = this.connById(agent.connectionId);
    const run = existingRun || {
      id: uid(), type: runType, taskId, projectId, agentId: agent.id, connectionId: conn.id,
      model: agent.model, status: "running", startedAt: now(), finishedAt: null,
      step: 0, steps: [], error: null
    };
    if (!existingRun) {
      this.db.runs.push(run);
      if (this.db.runs.length > 400) this.db.runs.splice(0, this.db.runs.length - 400);
      this.persist();
    }
    const t0 = now();
    try {
      const apiKey = await this.connKey(conn);
      const res = await chat(conn, apiKey, agent.model, messages, {
        maxTokens, temperature, rateGate: c => this.rateGate(c, { background })
      });
      run.providerModel = res.providerModel;
      run.steps.push({ at: now(), kind: "model", latencyMs: now() - t0, usage: res.usage, requestId: res.requestId, text: res.text.slice(0, 600) });
      if (!existingRun) { run.status = "completed"; run.finishedAt = now(); }
      this.persist();
      return { text: res.text, run, usage: res.usage };
    } catch (err) {
      if (err.code === "PROVIDER_WAIT") {
        run.steps.push({ at: now(), kind: "system", text: "أُجّل النداء إلى نافذة المزود المجاني التالية" });
        if (!existingRun) { run.status = "interrupted"; run.finishedAt = null; }
      } else {
        run.steps.push({ at: now(), kind: "error", text: String(err.message || err).slice(0, 500) });
        if (!existingRun) { run.status = "failed"; run.finishedAt = now(); run.error = String(err.message || err).slice(0, 500); }
      }
      this.persist();
      throw err;
    }
  }

  /* ---------- تنفيذ مهمة: خطوة واحدة محفوظة في كل استيقاظ ---------- */
  buildAgentMessages(agent, task, project) {
    const deps = (task.dependsOn || []).map(id => this.taskById(id)).filter(Boolean);
    let inputs = "";
    for (const dep of deps) {
      const art = this.db.artifacts.find(x => x.id === dep.deliverableArtifactId);
      const txt = this.artifactText(art);
      inputs += "\n\n--- مخرجات معتمدة من خطوة «" + dep.title + "» (" + (this.agentById(dep.agentId)?.name || "") + ") ---\n" +
        (txt ? txt.slice(0, 6500) : ("[مستند " + (art?.kind || "") + " رقم " + (art?.id || "؟") + ": " + (art?.title || "") + "]"));
      for (const id of dep.artifactIds || []) {
        const x = this.db.artifacts.find(z => z.id === id);
        if (x) inputs += "\n[مرفق من الخطوة السابقة: " + x.kind + " " + x.id + " — " + x.title + "]";
      }
    }
    const tools = TOOL_DEFS.filter(t => (agent.tools || []).includes(t.id));
    const sys = agent.systemPrompt +
      "\n\nذاكرتك المهنية من مهام سابقة بالشركة:\n" + ((agent.memory || []).slice(-6).join("\n- ") || "(لا ذكريات بعد)") +
      "\n\nأدواتك المتاحة فعليًا في سحابة الشركة:\n" + (tools.length ? tools.map(t => "- " + t.id + ": " + t.desc).join("\n") : "(لا أدوات — اعمل من المدخلات فقط)") +
      "\n\nقواعد رد صارمة: ردك كل مرة يكون كائن JSON واحدًا فقط بلا أي نص خارجها، بإحدى صورتين:\n" +
      "{\"action\":\"tool\",\"tool\":\"web_search\",\"args\":{\"query\":\"...\"}}\nأو\n" +
      "{\"action\":\"final\",\"deliverable\":\"الناتج الكامل النهائي هنا\",\"summary\":\"سطر يلخص ما سلمته لذاكرتك\"}\n" +
      "استخدم أداة فقط عند حاجة حقيقية. الناتج النهائي بالعربية ما لم تتطلب المهمة غير ذلك. حقل deliverable يجب أن يكون نصًا واحدًا كاملًا (string) منسقًا بعناوين وأسطر — ممنوع أن يكون مصفوفة أو كائنات JSON بداخله. لا تخترع مصادر أو أرقامًا؛ إن استخدمت الويب اذكر روابطه داخل الناتج.";
    const user = "هدف المشروع الأصلي من المالك/المدير: " + project.goal +
      "\n\nمهمتك: " + task.title + "\nتعليمات المدير: " + task.instructions +
      "\nمعايير قبول المدير: " + (task.acceptanceCriteria || "جودة مهنية واكتمال وصدق مصادر") +
      (task.revisionNotes ? "\n\n⚠️ هذه إعادة عمل بعد رفض المدير للنسخة السابقة. ملاحظاته الواجب علاجها حرفيًا:\n" + task.revisionNotes : "") +
      (inputs ? "\n\nالمدخلات المعتمدة من زملائك:" + inputs : "\n\nلا مدخلات سابقة — أنت أول خطوة.");
    return [{ role: "system", content: sys }, { role: "user", content: user }];
  }

  createTaskRun(task, agent, project) {
    const run = {
      id: uid(), type: "agent_task", taskId: task.id, projectId: project.id, agentId: agent.id,
      connectionId: agent.connectionId, model: agent.model, status: "running", startedAt: now(), finishedAt: null,
      step: 0, maxSteps: this.db.settings.maxSteps, steps: [], messages: this.buildAgentMessages(agent, task, project),
      error: null, attempt: (task.attempts || 0) + 1,
      phase: "model", parseStrikes: 0, toolArtifactIds: [...(task.artifactIds || [])],
      pendingTool: null, forcedPromptAdded: false, leaseUntil: 0,
      finalText: null, finalSummary: null, finalMeta: null, finalArtifactId: null
    };
    this.db.runs.push(run);
    if (this.db.runs.length > 400) this.db.runs.splice(0, this.db.runs.length - 400);
    return run;
  }

  async finalizeTaskRun(task, run, agent, project) {
    const deliverable = String(run.finalText || "");
    if (!deliverable.trim()) throw new Error("التشغيل في مرحلة تسليم بلا ناتج محفوظ");
    let art = run.finalArtifactId ? this.db.artifacts.find(a => a.id === run.finalArtifactId) : null;
    if (!art) {
      art = this.db.artifacts.find(a => a.meta?.runId === run.id && a.meta?.finalForStep === run.step && a.kind === "text") || null;
    }
    if (!art) {
      art = await this.saveArtifact({
        kind: "text",
        title: task.title + " — " + project.title.slice(0, 55),
        ext: "md",
        data: deliverable,
        taskId: task.id,
        projectId: project.id,
        agentId: agent.id,
        meta: { model: agent.model, runId: run.id, revision: task.revisionCount || 0, finalForStep: run.step, ...(run.finalMeta || {}) }
      });
      run.finalArtifactId = art.id;
      this.persist();
    }

    task.deliverableArtifactId = art.id;
    task.artifactIds = [...new Set(run.toolArtifactIds || [])];
    task.status = "under_review";
    task.submittedAt = now();
    task.lastAction = run.finalMeta?.unstructured
      ? "سلّم ناتجًا (دون صيغة JSON) — لدى المدير للمراجعة"
      : run.finalMeta?.forcedFinal
        ? "سلّم الناتج (تسليم أخير بعد الجمع) — لدى المدير للمراجعة"
        : "سلّم الناتج للمدير — بانتظار مراجعة فعلية";
    task.reviewAttempt = 0;
    task.reviewMessages = null;
    run.status = "completed";
    run.finishedAt = now();
    run.leaseUntil = 0;
    run.phase = "completed";
    run.messages = [];
    run.finalText = null;
    agent.memory = agent.memory || [];
    agent.memory.push("سلّم «" + task.title + "» في «" + project.title + "»: " + String(run.finalSummary || "ناتج محفوظ بالمستندات").slice(0, 300));
    if (agent.memory.length > 30) agent.memory.splice(0, agent.memory.length - 30);
    this.activity("تسليم", "📤 سلّم " + agent.name + " «" + task.title + "» إلى المدير (مستند " + art.id + ").", { taskId: task.id });
    this.persist();
    return { worked: true, operation: "task_final", nextDelayMs: 1000 };
  }

  handleTaskError(task, run, err) {
    const message = String(err?.message || err || "خطأ غير معروف");
    if (run) { run.leaseUntil = 0; }

    if (err?.code === "PROVIDER_WAIT") {
      if (run) run.status = "interrupted";
      task.status = "queued";
      task.checkpointRunId = run?.id || task.checkpointRunId;
      task.nextRetryAt = err.retryAt || (now() + 50000);
      task.lastAction = "بانتظار نافذة المزود المجاني — ستكمل الحلقة تلقائيًا";
      this.persist();
      return { worked: false, operation: "task_provider_wait", nextAt: task.nextRetryAt };
    }

    const rateOrEmpty = err?.status === 402 || err?.status === 429 || err?.code === "EMPTY_RESPONSE" || /FREE_LIMIT|فارغ/.test(message);
    if ((rateOrEmpty || this.isTransientError(err)) && (task.rateWaits || 0) < 14 && err?.code !== "UNCONFIGURED") {
      task.rateWaits = (task.rateWaits || 0) + 1;
      if (run) run.status = "interrupted";
      task.status = "queued";
      task.checkpointRunId = run?.id || null;
      task.nextRetryAt = err?.retryAt || (now() + 50000);
      task.lastAction = "خطأ عابر من المزود — إعادة تلقائية " + task.rateWaits + " من نقطة الحفظ";
      this.activity("انتظار مزود", "⏳ مهمة «" + task.title + "» تنتظر المزود وستكمل تلقائيًا من نقطة حفظها.", { taskId: task.id });
      this.persist();
      return { worked: true, operation: "task_retry_scheduled", nextAt: task.nextRetryAt };
    }

    if (run && run.status === "running") {
      run.status = "failed";
      run.finishedAt = now();
      run.error = message.slice(0, 600);
      run.messages = [];
    }
    task.checkpointRunId = null;
    task.attempts = (task.attempts || 0) + 1;
    if (err?.code === "UNCONFIGURED") {
      task.status = "blocked_unconfigured";
      task.lastAction = "متوقفة حتى ربط نموذج بالوكيل";
    } else if (task.attempts >= 3) {
      task.status = "failed";
      task.lastAction = "فشل بعد ٣ محاولات: " + message.slice(0, 200);
      this.db.approvals.push({
        id: uid(), type: "task_failed", title: "مهمة فاشلة تحتاج قرار المالك: " + task.title,
        details: message.slice(0, 600), status: "pending", createdAt: now(), meta: { taskId: task.id }
      });
    } else {
      task.status = "queued";
      task.nextRetryAt = now() + task.attempts * 30000;
      task.lastAction = "ستعاد المحاولة " + (task.attempts + 1) + " بسبب: " + message.slice(0, 160);
    }
    this.activity("خطأ", "⚠️ مهمة «" + task.title + "»: " + message.slice(0, 250), { taskId: task.id });
    this.persist();
    return { worked: true, operation: "task_error", nextDelayMs: 1000 };
  }

  async advancePendingTool(task, run, agent, project) {
    const pending = run.pendingTool || {};
    const toolId = String(pending.tool || "");
    const args = pending.args || {};
    task.lastAction = "ينفّذ أداة: " + (TOOL_DEFS.find(t => t.id === toolId)?.name || toolId);
    task.heartbeatAt = now();
    run.leaseUntil = now() + 180000;
    this.persist();

    let result;
    try {
      result = await executeTool(toolId, args, {
        db: this.db,
        store: this.store,
        agent,
        task,
        getArtifactText: a => this.artifactText(a),
        saveArtifact: o => this.saveArtifact({ ...o, taskId: task.id, projectId: project.id, agentId: agent.id })
      });
    } catch (e) {
      result = { text: "الأداة فشلت فعليًا: " + e.message + " — أكمل دون اختراع نتيجة، واذكر القيد في تسليمك إن أثّر." };
    }

    run.toolArtifactIds = [...new Set([...(run.toolArtifactIds || []), ...((result && result.artifactIds) || [])])];
    run.steps.push({ at: now(), kind: "tool", tool: toolId, args, text: String(result?.text || "").slice(0, 500) });
    run.messages.push({
      role: "user",
      content: "نتيجة أداة " + toolId + " الحقيقية من سحابة الشركة:\n" + String(result?.text || "").slice(0, 3500) +
        "\n\nتبقّى لك " + Math.max(0, run.maxSteps - run.step) + " من خطوات النموذج. متى حصلت على ما يكفي سلّم فورًا بصيغة JSON النهائية ولا تفتح أدوات إضافية بلا ضرورة قصوى."
    });
    run.pendingTool = null;
    run.phase = "model";
    run.leaseUntil = 0;
    task.heartbeatAt = now();
    this.persist();
    return { worked: true, operation: "task_tool", nextDelayMs: 1000 };
  }

  async advanceAgentTask(task) {
    const agent = this.agentById(task.agentId);
    const project = this.projById(task.projectId);
    let run = task.checkpointRunId ? this.runById(task.checkpointRunId) : null;

    try {
      if (!agent || !project) throw new Error("مهمة بلا وكيل/مشروع صالح");
      if (!this.isConfigured(agent)) {
        task.status = "blocked_unconfigured";
        this.resourceRequest(
          "agent:" + agent.id,
          "الوكيل " + agent.name + " (" + agent.role + ") بلا نموذج مربوط",
          "مهمة «" + task.title + "» متوقفة حتى يربط المالك نموذجًا بهذا الوكيل من قسم اتصالات الذكاء."
        );
        this.persist();
        return { worked: true, operation: "task_blocked", nextDelayMs: 60000 };
      }

      if (!run || !["running", "interrupted"].includes(run.status) || !Array.isArray(run.messages) || !run.messages.length) {
        run = this.createTaskRun(task, agent, project);
        task.currentRunId = run.id;
        task.checkpointRunId = run.id;
        task.startedAt = task.startedAt || now();
        this.activity("تنفيذ", "🤖 بدأ " + agent.name + " تنفيذ «" + task.title + "» بنموذج " + agent.model + " (تشغيل " + run.id + ").", { taskId: task.id });
      } else if (run.status === "interrupted") {
        run.status = "running";
        run.steps.push({ at: now(), kind: "system", text: "استئناف من نقطة حفظ عند الخطوة " + run.step });
      }
      run.phase = run.phase || "model";
      run.parseStrikes = Number(run.parseStrikes || 0);
      run.toolArtifactIds = Array.isArray(run.toolArtifactIds) ? run.toolArtifactIds : [...(task.artifactIds || [])];
      task.status = "running";
      task.currentRunId = run.id;
      task.checkpointRunId = run.id;
      task.heartbeatAt = now();
      this.persist();

      if (this.db.company.paused) {
        run.status = "interrupted";
        task.status = "queued";
        task.lastAction = "متوقف مؤقتًا (اجتماع) — محفوظ عند الخطوة " + run.step;
        run.steps.push({ at: now(), kind: "system", text: "نقطة حفظ بسبب اجتماع" });
        this.persist();
        return { worked: true, operation: "task_paused_meeting", nextDelayMs: 1000 };
      }

      if (run.phase === "finalizing") return this.finalizeTaskRun(task, run, agent, project);
      if (run.phase === "tool") return this.advancePendingTool(task, run, agent, project);

      let forced = false;
      if (run.phase === "forced_final" || run.step >= run.maxSteps) {
        forced = true;
        run.phase = "forced_final";
        if (!run.forcedPromptAdded) {
          run.messages.push({
            role: "user",
            content: "انتهت خطوات الأدوات. سلّم الآن فورًا بصيغة JSON النهائية {action:final} اعتمادًا حصريًا على نتائج الأدوات الحقيقية التي جمعتها أعلاه، واذكر روابط المصادر داخل الناتج. لا تطلب أي أداة أخرى."
          });
          run.forcedPromptAdded = true;
        }
        task.lastAction = "خطوة تسليم أخيرة بعد اكتمال الجمع";
      } else {
        task.lastAction = "بانتظار رد النموذج — خطوة " + (run.step + 1) + "/" + run.maxSteps;
      }

      run.leaseUntil = now() + 180000;
      task.heartbeatAt = now();
      this.persist();

      const { text } = await this.callAgentModel(agent, run.messages, {
        runType: "agent_task", existingRun: run, maxTokens: 4000, background: true
      });
      run.leaseUntil = 0;
      run.messages.push({ role: "assistant", content: text });
      if (!forced) run.step++;
      this.persist();

      const act = this.extractJSON(text);
      if (forced) {
        const deliv = act?.action === "final" && this.deliverableToText(act.deliverable || "").trim().length > 30
          ? this.deliverableToText(act.deliverable)
          : (text.trim().length > 150 ? text.trim() : "");
        if (!deliv) throw new Error("استنفد الوكيل خطواته القصوى ولم يسلّم حتى في خطوة التسليم الأخيرة");
        run.phase = "finalizing";
        run.finalText = deliv;
        run.finalSummary = "سلّم بعد جمع بأدواته";
        run.finalMeta = { forcedFinal: true };
        this.persist();
        return this.finalizeTaskRun(task, run, agent, project);
      }

      if (act?.action === "tool") {
        run.parseStrikes = 0;
        const toolId = String(act.tool || "");
        if (!(agent.tools || []).includes(toolId) || !TOOL_DEFS.some(t => t.id === toolId)) {
          run.messages.push({
            role: "user",
            content: "الأداة «" + toolId + "» ليست ضمن صلاحياتك أو غير متاحة في هذه النسخة. أدواتك: " + (agent.tools || []).join(", ") + ". أكمل بدونها أو بأداة مسموحة بصيغة JSON المطلوبة."
          });
          this.persist();
          return { worked: true, operation: "task_tool_rejected", nextDelayMs: 1000 };
        }
        run.phase = "tool";
        run.pendingTool = { tool: toolId, args: act.args || {} };
        this.persist();
        return this.advancePendingTool(task, run, agent, project);
      }

      if (act?.action === "final" && this.deliverableToText(act.deliverable || "").trim().length > 30) {
        run.phase = "finalizing";
        run.finalText = this.deliverableToText(act.deliverable);
        run.finalSummary = String(act.summary || "ناتج محفوظ بالمستندات");
        run.finalMeta = {};
        this.persist();
        return this.finalizeTaskRun(task, run, agent, project);
      }

      run.parseStrikes++;
      if (run.parseStrikes >= 2 && text.trim().length > 250) {
        run.phase = "finalizing";
        run.finalText = text.trim();
        run.finalSummary = "ناتج حقيقي غير مهيكل من النموذج";
        run.finalMeta = { unstructured: true };
        run.steps.push({ at: now(), kind: "system", text: "النموذج لم يلتزم JSON؛ سُلّم نصه الحقيقي كما وصل" });
        this.persist();
        return this.finalizeTaskRun(task, run, agent, project);
      }

      run.messages.push({
        role: "user",
        content: "ردك لم يطابق الصيغة. أعد الرد الآن كائن JSON واحدًا فقط: إما action=tool وإما action=final مع deliverable كامل."
      });
      this.persist();
      return { worked: true, operation: "task_format_retry", nextDelayMs: 1000 };
    } catch (err) {
      return this.handleTaskError(task, run, err);
    }
  }

  /* ---------- تخطيط ومراجعة بخطوة نموذج واحدة ---------- */
  async advancePlan(project) {
    const boss = this.ceo();
    if (!this.isConfigured(boss)) {
      project.status = "waiting_ceo_config";
      this.resourceRequest("ceo", "الرئيس التنفيذي زياد بلا نموذج مربوط — التخطيط متوقف", "هدف «" + project.title + "» بانتظار ربط نموذج للمدير.");
      this.persist();
      return { worked: true, operation: "plan_blocked", nextDelayMs: 60000 };
    }

    if (!Array.isArray(project.planMessages) || !project.planMessages.length) {
      const roster = this.db.agents.filter(a => !a.isCeo).map(a => ({
        id: a.id, name: a.name, role: a.role, configured: this.isConfigured(a), model: a.model || null, tools: a.tools
      }));
      project.planMessages = [
        { role: "system", content: boss.systemPrompt + "\nحوّل الهدف إلى خطة مهام قابلة للتنفيذ. ردك كائن JSON واحد فقط:\n{\"summary\":\"ملخص خطتك\",\"tasks\":[{\"title\":\"...\",\"agentId\":\"a4\",\"instructions\":\"تعليمات تنفيذ مفصلة\",\"acceptanceCriteria\":\"معايير قبول قابلة للفحص\",\"dependsOn\":[0],\"rationale\":\"لماذا هذا الوكيل\"}],\"missingCapabilities\":[\"قدرة ناقصة إن وجدت\"]}\nقوانين: أسند فقط لوكلاء configured=true من القائمة وبمعرفاتهم الدقيقة. بحد أقصى " + this.db.settings.maxTasksPerProject + " مهام. سلسل الاعتمادات بفهارس المهام السابقة. إن احتجت وكيلًا غير مهيأ لا تُسند إليه واذكر الحاجة في missingCapabilities." },
        { role: "user", content: "الهدف: " + project.goal + "\n\nفريقك (JSON):\n" + JSON.stringify(roster) }
      ];
      project.planAttempt = 0;
      this.persist();
    }

    try {
      const r = await this.callAgentModel(boss, project.planMessages, {
        runType: "ceo_plan", projectId: project.id, maxTokens: 2600, temperature: 0.4, background: true
      });
      project.planLastRunId = r.run.id;
      const plan = this.extractJSON(r.text);
      if (!plan || !Array.isArray(plan.tasks) || !plan.tasks.length) {
        project.planAttempt = Number(project.planAttempt || 0) + 1;
        project.planMessages.push(
          { role: "assistant", content: r.text },
          { role: "user", content: "أعد الخطة بصيغة JSON المطلوبة فقط وبمعرفات وكلاء من القائمة." }
        );
        if (project.planAttempt >= 2) {
          project.status = "planning_failed";
          project.planError = "تعذّر الحصول على خطة مهيكلة من نموذج المدير بعد محاولتين";
          project.planMessages = null;
          this.activity("خطأ", "فشل تخطيط مشروع «" + project.title + "» — نموذج المدير لم يعط خطة صالحة. يمكن إعادة المحاولة من المشاريع.", { projectId: project.id });
        }
        this.persist();
        return { worked: true, operation: "plan_retry", nextDelayMs: 1000 };
      }

      const selected = plan.tasks.slice(0, this.db.settings.maxTasksPerProject);
      const ids = selected.map(() => uid());
      selected.forEach((t, i) => {
        const agent = this.agentById(t.agentId);
        if (!agent || agent.isCeo) {
          this.activity("تخطيط", "تجاهل المدير مهمة بمعرف وكيل غير صالح (" + t.agentId + ") في «" + project.title + "».", { projectId: project.id });
          return;
        }
        const task = {
          id: ids[i], projectId: project.id, agentId: agent.id,
          title: String(t.title || "مهمة").slice(0, 120),
          instructions: String(t.instructions || ""),
          acceptanceCriteria: String(t.acceptanceCriteria || ""),
          why: String(t.rationale || ""),
          dependsOn: (t.dependsOn || []).map(x => ids[Number(x)]).filter(Boolean),
          status: this.isConfigured(agent) ? "queued" : "blocked_unconfigured",
          attempts: 0, revisionCount: 0, createdAt: now(), originRunId: r.run.id,
          lastAction: this.isConfigured(agent) ? "في الطابور" : "بانتظار تهيئة نموذج الوكيل"
        };
        this.db.tasks.push(task);
        this.activity("تكليف", "🧭 كلّف المدير زياد " + agent.name + " بـ«" + task.title + "»" + (task.why ? " — السبب: " + task.why : ""), { taskId: task.id, projectId: project.id });
      });
      (plan.missingCapabilities || []).forEach((c, i) => this.resourceRequest(
        "cap:" + project.id + ":" + i,
        "قدرة ناقصة أبلغ عنها المدير زياد: " + String(c).slice(0, 150),
        "ظهرت أثناء تخطيط مشروع «" + project.title + "»."
      ));
      project.status = "active";
      project.planSummary = String(plan.summary || "");
      project.plannedByRunId = r.run.id;
      project.planMessages = null;
      project.planAttempt = 0;
      project.planNextRetryAt = 0;
      project.planErrorCount = 0;
      this.db.decisions.push({ id: uid(), at: now(), kind: "plan", runId: r.run.id, text: "خطط المدير لمشروع «" + project.title + "»: " + project.planSummary.slice(0, 400) });
      this.activity("تخطيط", "🧭 أنهى المدير زياد تخطيط «" + project.title + "» (" + selected.length + " مهمة). " + project.planSummary.slice(0, 220), { projectId: project.id });
      this.persist();
      return { worked: true, operation: "plan", nextDelayMs: 1000 };
    } catch (e) {
      if (e.code === "PROVIDER_WAIT") {
        project.planNextRetryAt = e.retryAt || (now() + 50000);
        this.persist();
        return { worked: false, operation: "plan_provider_wait", nextAt: project.planNextRetryAt };
      }
      if (this.isTransientError(e) && Number(project.planErrorCount || 0) < 3) {
        project.planErrorCount = Number(project.planErrorCount || 0) + 1;
        project.planNextRetryAt = now() + 60000;
        project.planError = String(e.message || e).slice(0, 400);
        this.activity("خطأ", "تعثر تخطيط «" + project.title + "» مؤقتًا وستكمل الحلقة: " + String(e.message || e).slice(0, 180), { projectId: project.id });
        this.persist();
        return { worked: true, operation: "plan_transient_error", nextAt: project.planNextRetryAt };
      }
      project.status = "planning_failed";
      project.planError = String(e.message || e).slice(0, 400);
      project.planMessages = null;
      this.activity("خطأ", "خطأ تخطيط «" + project.title + "»: " + String(e.message || e).slice(0, 220), { projectId: project.id });
      this.persist();
      return { worked: true, operation: "plan_failed", nextDelayMs: 1000 };
    }
  }

  completeProjectIfDone(project) {
    const mine = this.db.tasks.filter(t => t.projectId === project.id);
    if (mine.length && mine.every(t => ["approved", "cancelled"].includes(t.status))) {
      project.status = "completed";
      project.completedAt = now();
      this.activity("مشروع", "🏁 اكتمل مشروع «" + project.title + "» واعتُمدت كل مهامه.", { projectId: project.id });
    } else if (mine.length && mine.every(t => ["approved", "cancelled", "failed"].includes(t.status))) {
      project.status = "completed_with_issues";
      project.completedAt = now();
      this.activity("مشروع", "🏁 أُغلق مشروع «" + project.title + "» مع مهام فاشلة موثقة.", { projectId: project.id });
    }
  }

  async advanceReview(task) {
    const boss = this.ceo();
    const project = this.projById(task.projectId);
    const agent = this.agentById(task.agentId);
    if (!project || !agent) {
      task.nextRetryAt = now() + 3600000;
      task.lastAction = "تعذر المراجعة: المشروع أو الوكيل غير موجود";
      this.persist();
      return { worked: true, operation: "review_invalid", nextAt: task.nextRetryAt };
    }
    if (!this.isConfigured(boss)) {
      this.resourceRequest("ceo", "الرئيس التنفيذي زياد بلا نموذج مربوط — المراجعات متوقفة", "مهمة «" + task.title + "» مسلّمة وتنتظر مراجعة.");
      this.persist();
      return { worked: true, operation: "review_blocked", nextDelayMs: 60000 };
    }

    if (!Array.isArray(task.reviewMessages) || !task.reviewMessages.length) {
      const art = this.db.artifacts.find(a => a.id === task.deliverableArtifactId);
      const deliverable = this.artifactText(art) || ("[مستند غير نصي: " + (art?.title || "") + "]");
      task.reviewMessages = [
        { role: "system", content: boss.systemPrompt + "\nأنت الآن في دور المراجع. قيّم بصدق وصرامة مهنية. ردك كائن JSON واحد فقط:\n{\"verdict\":\"approve|revise|reject\",\"score\":0-100,\"feedback\":\"تقييم مكتوب محدد\",\"requiredChanges\":[\"تغيير مطلوب\"]}\nاعتمد فقط ما يحقق معايير القبول فعلًا. ما دون ذلك revise إن كان قابلًا للإصلاح وreject إن كان ضعيفًا جوهريًا." },
        { role: "user", content: "مشروع: " + project.title + "\nالهدف الأصلي: " + project.goal + "\nالمهمة: " + task.title + "\nالتعليمات كانت: " + task.instructions + "\nمعايير القبول: " + (task.acceptanceCriteria || "—") + "\nنفّذها: " + agent.name + " بنموذج " + agent.model + "\n\nالناتج المسلّم حرفيًا:\n" + deliverable.slice(0, 9000) }
      ];
      task.reviewAttempt = 0;
      this.persist();
    }

    try {
      const r = await this.callAgentModel(boss, task.reviewMessages, {
        runType: "ceo_review", taskId: task.id, projectId: project.id, maxTokens: 3000, temperature: 0.3, background: true
      });
      task.reviewLastRunId = r.run.id;
      const verdict = this.extractJSON(r.text);
      if (!verdict || !["approve", "revise", "reject"].includes(verdict.verdict)) {
        task.reviewAttempt = Number(task.reviewAttempt || 0) + 1;
        if (task.reviewAttempt >= 2) {
          task.reviewMessages = null;
          task.reviewAttempt = 0;
          task.reviewErrorAt = now();
          task.nextRetryAt = now() + 60000;
          this.activity("خطأ", "تعذّر الحصول على قرار مراجعة مهيكل للمدير لمهمة «" + task.title + "» — ستعاد المراجعة تلقائيًا.", { taskId: task.id });
          this.persist();
          return { worked: true, operation: "review_format_failed", nextAt: task.nextRetryAt };
        }
        task.reviewMessages.push(
          { role: "assistant", content: r.text },
          { role: "user", content: "أعد بصيغة JSON المطلوبة فقط." }
        );
        this.persist();
        return { worked: true, operation: "review_retry", nextDelayMs: 1000 };
      }

      const rev = {
        id: uid(), taskId: task.id, projectId: project.id, agentId: agent.id, runId: r.run.id,
        verdict: verdict.verdict, score: Math.round(Number(verdict.score) || 0),
        feedback: String(verdict.feedback || ""), requiredChanges: verdict.requiredChanges || [], at: now()
      };
      this.db.reviews.push(rev);
      task.lastReviewId = rev.id;
      task.reviewMessages = null;
      task.reviewAttempt = 0;
      agent.memory = agent.memory || [];
      agent.memory.push("مراجعة مدير على «" + task.title + "»: " + rev.verdict + " (" + rev.score + "/١٠٠) — " + rev.feedback.slice(0, 220));

      if (rev.verdict === "approve") {
        task.status = "approved";
        task.completedAt = now();
        task.lastAction = "معتمدة من المدير (" + rev.score + "/١٠٠)";
        this.activity("اعتماد", "✅ اعتمد المدير زياد «" + task.title + "» من " + agent.name + " بدرجة " + rev.score + "/١٠٠: " + rev.feedback.slice(0, 180), { taskId: task.id });
        this.completeProjectIfDone(project);
      } else {
        task.revisionCount = (task.revisionCount || 0) + 1;
        if (task.revisionCount > 2) {
          task.status = "failed";
          task.lastAction = "استنفدت مراجعات المدير (آخر درجة " + rev.score + ")";
          this.db.approvals.push({
            id: uid(), type: "task_failed", title: "مهمة لم تجتز مراجعة المدير: " + task.title,
            details: rev.feedback + "\nالمطلوب كان: " + (rev.requiredChanges || []).join("؛ "),
            status: "pending", createdAt: now(), meta: { taskId: task.id }
          });
          this.activity("رفض", "❌ أغلق المدير زياد «" + task.title + "» بعد استنفاد المراجعات (" + rev.score + "/١٠٠) ورفعها لقرار المالك.", { taskId: task.id });
          this.completeProjectIfDone(project);
        } else {
          task.status = "queued";
          task.attempts = 0;
          task.rateWaits = 0;
          task.checkpointRunId = null;
          task.currentRunId = null;
          task.nextRetryAt = 0;
          task.revisionNotes = rev.feedback + "\nالتغييرات المطلوبة:\n- " + (rev.requiredChanges || []).join("\n- ");
          task.lastAction = "أعادها المدير للتعديل (" + rev.score + "/١٠٠)";
          this.activity("تعديل مطلوب", "↩️ طلب المدير زياد تعديل «" + task.title + "» من " + agent.name + " (" + rev.score + "/١٠٠): " + rev.feedback.slice(0, 200), { taskId: task.id });
        }
      }
      this.persist();
      return { worked: true, operation: "review", nextDelayMs: 1000 };
    } catch (e) {
      if (e.code === "PROVIDER_WAIT") {
        task.nextRetryAt = e.retryAt || (now() + 50000);
        this.persist();
        return { worked: false, operation: "review_provider_wait", nextAt: task.nextRetryAt };
      }
      task.nextRetryAt = now() + 60000;
      this.activity("خطأ", "خطأ أثناء مراجعة «" + task.title + "»: " + String(e.message || e).slice(0, 220), { taskId: task.id });
      this.persist();
      return { worked: true, operation: "review_error", nextAt: task.nextRetryAt };
    }
  }

  /* ---------- ملخص ومسح واجتماعات ---------- */
  companyDigest() {
    const conf = this.db.agents.filter(a => !a.isCeo && this.isConfigured(a));
    const unconf = this.db.agents.filter(a => !a.isCeo && !this.isConfigured(a));
    return {
      مشاريع_نشطة: this.db.projects.filter(p => p.status === "active").map(p => ({
        عنوان: p.title,
        مهام: this.db.tasks.filter(t => t.projectId === p.id).map(t => t.title + " [" + t.status + "]")
      })),
      مشاريع_مكتملة: this.db.projects.filter(p => String(p.status || "").startsWith("completed")).length,
      مهام_فاشلة: this.db.tasks.filter(t => t.status === "failed").map(t => t.title),
      مهام_بانتظار_تهيئة: this.db.tasks.filter(t => t.status === "blocked_unconfigured").map(t => t.title),
      وكلاء_مهيأون: conf.map(a => a.name + " (" + a.role + ")"),
      وكلاء_غير_مهيأين: unconf.map(a => a.name + " (" + a.role + ")"),
      موافقات_معلقة: this.db.approvals.filter(a => a.status === "pending").length,
      مستندات: this.db.artifacts.length,
      آخر_مستندات: this.db.artifacts.slice(-6).map(a => a.title),
      آخر_أحداث: this.db.activity.slice(-8).map(a => a.text)
    };
  }

  async runCeoScan(force = false) {
    const boss = this.ceo();
    if (!this.isConfigured(boss) || (!force && !this.db.settings.autonomy.enabled)) return { worked: false, operation: "scan_skip" };
    if (!force && now() - Number(this.db.settings.autonomy.lastScanAt || 0) < Number(this.db.settings.autonomy.scanMinutes || 10) * 60000) {
      return { worked: false, operation: "scan_not_due" };
    }
    if (this._scanBusy) return { worked: false, operation: "scan_busy" };
    this._scanBusy = true;
    const previousScanAt = this.db.settings.autonomy.lastScanAt || 0;
    this.db.settings.autonomy.lastScanAt = now();
    this.persist();
    try {
      const messages = [
        { role: "system", content: boss.systemPrompt + "\nهذه جلسة مسحك الاستقلالي الدوري. ادرس حالة الشركة الحقيقية (JSON) وقرر بحد أقصى 3 إجراءات ذات قيمة حقيقية الآن. ردك JSON واحد فقط:\n{\"assessment\":\"تقييمك المختصر للوضع\",\"actions\":[{\"type\":\"create_project\",\"goal\":\"...\"},{\"type\":\"request_resource\",\"title\":\"...\",\"details\":\"...\"},{\"type\":\"propose_improvement\",\"title\":\"...\",\"details\":\"...\"},{\"type\":\"none\"}]}\nلا تقترح مشروعًا جديدًا إن كانت المشاريع النشطة كافية. لا أفعال خارجية (نشر/إنفاق) إطلاقًا من عندك." },
        { role: "user", content: JSON.stringify(this.companyDigest()) }
      ];
      const r = await this.callAgentModel(boss, messages, { runType: "ceo_scan", maxTokens: 2400, temperature: 0.4, background: true });
      const out = this.extractJSON(r.text);
      this.db.decisions.push({ id: uid(), at: now(), kind: "scan", runId: r.run.id, text: String(out?.assessment || r.text).slice(0, 600) });
      this.activity("مسح المدير", "🧭 مسح استقلالي للمدير: " + String(out?.assessment || "(لم يعد بصيغة مهيكلة)").slice(0, 240));
      for (const a of (out?.actions || []).slice(0, 3)) {
        if (a.type === "create_project" && a.goal && this.db.settings.autonomy.allowAutoProjects) {
          if (this.db.projects.filter(p => p.status === "active").length >= 2) {
            this.activity("مسح المدير", "تجاهل النظام إنشاء مشروع ذاتي جديد لوجود مشروعين نشطين.");
            continue;
          }
          const p = { id: uid(), title: String(a.goal).slice(0, 90), goal: String(a.goal), origin: "ceo_autonomous", status: "planning", createdAt: now() };
          this.db.projects.push(p);
          this.activity("مشروع", "🤖 بادر المدير زياد ذاتيًا بمشروع: «" + p.title + "»", { projectId: p.id });
        } else if (a.type === "request_resource" && a.title) {
          this.resourceRequest("scan:" + String(a.title).trim().slice(0, 80), String(a.title).slice(0, 180), String(a.details || ""));
        } else if (a.type === "propose_improvement" && a.title) {
          const title = String(a.title).slice(0, 180);
          if (!this.db.approvals.some(x => x.status === "pending" && x.title === title)) {
            this.db.approvals.push({ id: uid(), type: "improvement", title, details: String(a.details || ""), status: "pending", createdAt: now(), meta: { byCeo: true } });
            this.activity("اقتراح", "💡 اقتراح تحسين من المدير زياد: " + title);
          }
        }
      }
      this.db.loop.forceScan = false;
      this.persist();
      return { worked: true, operation: "ceo_scan", nextDelayMs: 1000 };
    } catch (e) {
      if (e.code === "PROVIDER_WAIT") {
        this.db.settings.autonomy.lastScanAt = previousScanAt;
        this.persist();
        return { worked: false, operation: "scan_provider_wait", nextAt: e.retryAt || (now() + 50000) };
      }
      this.db.loop.forceScan = false;
      this.activity("خطأ", "فشل المسح الاستقلالي للمدير: " + String(e.message || e).slice(0, 200));
      this.persist();
      return { worked: true, operation: "ceo_scan_error", nextDelayMs: 60000 };
    } finally { this._scanBusy = false; }
  }

  createMeeting(type, by) {
    const boss = this.ceo();
    if (!this.isConfigured(boss)) {
      this.resourceRequest("ceo", "لا يمكن عقد اجتماع: الرئيس التنفيذي زياد بلا نموذج", "اربط نموذجًا للمدير أولًا.");
      return { error: "الرئيس التنفيذي زياد غير مهيأ بنموذج — لا اجتماعات ممثلة دون نماذج." };
    }
    const attendees = this.db.agents.filter(a => !a.isCeo && this.isConfigured(a));
    if (!attendees.length) return { error: "لا يوجد موظفون مهيأون بنماذج لحضور اجتماع حقيقي." };
    if (this.db.company.activeMeetingId) return { error: "يوجد اجتماع منعقد بالفعل." };
    const meeting = {
      id: uid(), type, by, startedAt: now(), endedAt: null, status: "in_progress",
      agenda: "مراجعة المشاريع النشطة ونتائج المراجعات الأخيرة والمشكلات والمقترحات. حالة الشركة لحظة الاجتماع: " + JSON.stringify(this.companyDigest()).slice(0, 1600),
      queue: ["ceo_open", ...attendees.map(a => a.id), "ceo_close"],
      contributions: [], nextRetryAt: 0
    };
    this.db.meetings.push(meeting);
    this.db.company.paused = true;
    this.db.company.activeMeetingId = meeting.id;
    this.activity("اجتماع", "📋 بدأ اجتماع " + type + " بحضور المدير زياد و" + attendees.length + " موظفًا مهيأًا. تقدم المهام الجارية محفوظ بنقاط حفظ وسيُستأنف.");
    this.persist();
    return { meeting };
  }

  async advanceMeeting() {
    const meeting = this.db.meetings.find(x => x.id === this.db.company.activeMeetingId);
    if (!meeting) {
      this.db.company.activeMeetingId = null;
      this.db.company.paused = false;
      this.persist();
      return { worked: true, operation: "meeting_missing_cleared", nextDelayMs: 1000 };
    }
    if (this._meetingBusy) return { worked: false, operation: "meeting_busy" };
    if (meeting.nextRetryAt && meeting.nextRetryAt > now()) return { worked: false, operation: "meeting_wait", nextAt: meeting.nextRetryAt };
    this._meetingBusy = true;
    try {
      const item = meeting.queue[0];
      if (!item) {
        meeting.status = "done";
        meeting.endedAt = now();
        this.db.company.paused = false;
        this.db.company.activeMeetingId = null;
        const transcript = await this.saveArtifact({
          kind: "text",
          title: "محضر اجتماع " + meeting.type + " — " + new Date(meeting.startedAt).toLocaleDateString("ar-EG"),
          ext: "md",
          data: meeting.contributions.map(c => "## " + c.name + "\n" + c.text).join("\n\n"),
          agentId: "ceo",
          meta: { meetingId: meeting.id }
        });
        meeting.transcriptArtifactId = transcript.id;
        if (meeting.type === "أسبوعي") this.db.settings.nextWeeklyMeeting = now() + 7 * 864e5;
        this.activity("اجتماع", "✅ انتهى الاجتماع وحُفظ محضره (مستند " + transcript.id + "). استؤنف العمل من نقاط الحفظ.");
        this.persist();
        return { worked: true, operation: "meeting_done", nextDelayMs: 1000 };
      }

      if (item === "ceo_open" || item === "ceo_close") {
        const boss = this.ceo();
        const prompt = item === "ceo_open"
          ? "افتتح اجتماعًا " + meeting.type + " لشركتك بجلسة مركزة: لخص الوضع من جدول الأعمال التالي وحدد ما تريد سماعه من كل فريق. ١٥٠ كلمة حدًا أقصى.\n" + meeting.agenda
          : "اختم الاجتماع: لخص أهم ما قاله فريقك حرفيًا في المساهمات التالية، واستخرج قرارات ومتابعات محددة. ٢٥٠ كلمة حدًا أقصى.\n" + meeting.contributions.map(c => c.name + ": " + c.text).join("\n").slice(0, 7000);
        const r = await this.callAgentModel(boss, [
          { role: "system", content: boss.systemPrompt },
          { role: "user", content: prompt }
        ], { runType: "meeting", maxTokens: 1600, background: true });
        meeting.contributions.push({
          agentId: "ceo",
          name: item === "ceo_open" ? "الرئيس التنفيذي زياد (افتتاح)" : "الرئيس التنفيذي زياد (قرارات ختامية)",
          text: r.text, at: now(), runId: r.run.id
        });
      } else {
        const agent = this.agentById(item);
        if (!agent) throw new Error("وكيل الاجتماع غير موجود: " + item);
        const myTasks = this.db.tasks.filter(t => t.agentId === agent.id);
        const current = myTasks.filter(t => ["queued", "running", "under_review"].includes(t.status))
          .map(t => t.title + " [" + t.status + "]").join("؛ ") || "لا شيء";
        const prompt = "أنت في اجتماع " + meeting.type + " بالشركة. جدول الأعمال:\n" + meeting.agenda.slice(0, 900) +
          "\n\nوضعك الفعلي: أنجزت " + myTasks.filter(t => t.status === "approved").length +
          " مهمة معتمدة، مهامك الحالية: " + current + ". ذاكرتك: " + (agent.memory || []).slice(-4).join(" | ") +
          "\nقدّم مداخلة صادقة مركزة (١٠٠ كلمة): تقدمك، مشكلة واجهتها إن وجدت من سجلاتك، وحاجة أو مقترح واحد.";
        const r = await this.callAgentModel(agent, [
          { role: "system", content: agent.systemPrompt },
          { role: "user", content: prompt }
        ], { runType: "meeting", maxTokens: 1200, background: true });
        meeting.contributions.push({ agentId: agent.id, name: agent.name + " — " + agent.role, text: r.text, at: now(), runId: r.run.id });
      }
      meeting.queue.shift();
      meeting.nextRetryAt = 0;
      this.persist();
      return { worked: true, operation: "meeting_contribution", nextDelayMs: 1000 };
    } catch (e) {
      if (e.code === "PROVIDER_WAIT") {
        meeting.nextRetryAt = e.retryAt || (now() + 50000);
        this.persist();
        return { worked: false, operation: "meeting_provider_wait", nextAt: meeting.nextRetryAt };
      }
      meeting.nextRetryAt = now() + 60000;
      this.activity("خطأ", "تعثرت مساهمة اجتماع: " + String(e.message || e).slice(0, 180) + " — ستُعاد المحاولة.");
      this.persist();
      return { worked: true, operation: "meeting_error", nextAt: meeting.nextRetryAt };
    } finally { this._meetingBusy = false; }
  }

  /* ---------- الحلقة والجدولة ---------- */
  depsApproved(task) {
    return (task.dependsOn || []).every(id => {
      const dep = this.taskById(id);
      return dep && ["approved", "cancelled"].includes(dep.status);
    });
  }

  recoverExpiredLeases() {
    let changed = false;
    for (const run of this.db.runs) {
      if (run.status !== "running") continue;
      if (run.leaseUntil && run.leaseUntil > now()) continue;
      run.status = "interrupted";
      run.leaseUntil = 0;
      run.steps = Array.isArray(run.steps) ? run.steps : [];
      run.steps.push({ at: now(), kind: "system", text: "انقطع الاستيقاظ السابق — قابل للاستئناف من نقطة الحفظ" });
      changed = true;
      const task = run.taskId ? this.taskById(run.taskId) : null;
      if (task && task.status === "running") {
        task.status = "queued";
        task.checkpointRunId = run.id;
        task.lastAction = "استُرد بعد انقطاع الاستيقاظ وسيُستأنف من نقطة الحفظ";
      }
    }
    if (this.db.company.activeMeetingId) {
      const meeting = this.db.meetings.find(x => x.id === this.db.company.activeMeetingId);
      if (meeting && meeting.status !== "in_progress") {
        this.db.company.paused = false;
        this.db.company.activeMeetingId = null;
        changed = true;
      }
    }
    if (changed) this.persist();
  }

  nextPlanProject() {
    if (!this.isConfigured(this.ceo())) return null;
    return this.db.projects.find(p =>
      ["planning", "waiting_ceo_config"].includes(p.status) && (!p.planNextRetryAt || p.planNextRetryAt <= now())
    ) || null;
  }

  nextReviewTask() {
    return this.db.tasks.find(t => t.status === "under_review" && (!t.nextRetryAt || t.nextRetryAt <= now())) || null;
  }

  nextAgentTask() {
    for (const task of this.db.tasks) {
      if (task.status === "blocked_unconfigured" && this.isConfigured(this.agentById(task.agentId))) {
        task.status = "queued";
        task.lastAction = "في الطابور (تمت التهيئة)";
        this.mark();
      }
    }
    const candidates = this.db.tasks.filter(task => {
      if (!["queued", "running"].includes(task.status)) return false;
      if (task.nextRetryAt && task.nextRetryAt > now()) return false;
      const project = this.projById(task.projectId);
      if (!project || project.status !== "active" || !this.depsApproved(task)) return false;
      const agent = this.agentById(task.agentId);
      if (!agent || !this.isConfigured(agent)) return false;
      const run = task.checkpointRunId ? this.runById(task.checkpointRunId) : null;
      if (run?.leaseUntil && run.leaseUntil > now()) return false;
      if (this.providerReadyAt(agent) > now() && run?.phase !== "tool" && run?.phase !== "finalizing") return false;
      return true;
    });
    candidates.sort((a, b) => {
      const ac = a.checkpointRunId ? 0 : 1;
      const bc = b.checkpointRunId ? 0 : 1;
      return ac - bc || (a.createdAt || 0) - (b.createdAt || 0);
    });
    return candidates[0] || null;
  }

  hasPendingWork() {
    if (!this.db.loop.enabled) return false;
    if (this.db.company.activeMeetingId || this.db.loop.forceScan) return true;
    if (this.db.projects.some(p => ["planning", "waiting_ceo_config"].includes(p.status))) return true;
    return this.db.tasks.some(t => ["queued", "running", "under_review", "blocked_unconfigured"].includes(t.status));
  }

  computeNextWake(preferredAt = null) {
    if (!this.db.loop.enabled) return null;
    const candidates = [];
    if (preferredAt) candidates.push(preferredAt);
    for (const task of this.db.tasks) {
      if (["queued", "running", "under_review"].includes(task.status) && task.nextRetryAt) candidates.push(task.nextRetryAt);
      if (task.status === "queued" || task.status === "under_review") candidates.push(now() + 60000);
    }
    for (const run of this.db.runs) if (run.status === "running" && run.leaseUntil) candidates.push(run.leaseUntil);
    for (const project of this.db.projects) if (project.planNextRetryAt) candidates.push(project.planNextRetryAt);
    for (const meeting of this.db.meetings) if (meeting.status === "in_progress" && meeting.nextRetryAt) candidates.push(meeting.nextRetryAt);
    if (this.hasPendingWork() && this.db.loop.freeProviderNextAt) candidates.push(this.db.loop.freeProviderNextAt);

    if (this.db.settings.autonomy?.enabled && this.isConfigured(this.ceo())) {
      const scanAt = Number(this.db.settings.autonomy.lastScanAt || 0) + Number(this.db.settings.autonomy.scanMinutes || 10) * 60000;
      candidates.push(scanAt);
    }
    if (this.db.settings.weeklyMeetings) candidates.push(Number(this.db.settings.nextWeeklyMeeting || 0));
    for (const agent of this.db.agents) {
      if (agent.summon?.active && agent.summon.expiresAt) candidates.push(agent.summon.expiresAt);
    }

    const valid = candidates.filter(x => Number.isFinite(Number(x)) && Number(x) > 0).map(Number);
    if (!valid.length) return now() + 60 * 60000;
    return Math.min(...valid);
  }

  async scheduleAt(timestamp) {
    if (!this.setAlarmFn || !timestamp) return null;
    const target = Math.max(now() + 1000, Math.min(Number(timestamp), now() + 365 * 864e5));
    let current = null;
    try { current = this.getAlarmFn ? await this.getAlarmFn() : null; } catch {}
    this.db.loop.nextWakeAt = target;
    this.persist();
    if (!current || Math.abs(Number(current) - target) > 1000) await this.setAlarmFn(target);
    return target;
  }

  async scheduleAfter(result = {}) {
    if (!this.db.loop.enabled) {
      this.db.loop.nextWakeAt = null;
      this.persist();
      try { if (this.deleteAlarmFn) await this.deleteAlarmFn(); } catch {}
      return null;
    }
    const preferred = result.nextAt || (result.nextDelayMs !== undefined ? now() + Number(result.nextDelayMs) : null);
    return this.scheduleAt(this.computeNextWake(preferred));
  }

  async ensureScheduled(delayMs = 1000, forceNear = false) {
    if (!this.db.loop.enabled) return null;
    let current = null;
    try { current = this.getAlarmFn ? await this.getAlarmFn() : null; } catch {}
    if (forceNear || !current) return this.scheduleAt(now() + Math.max(250, Number(delayMs) || 1000));
    this.db.loop.nextWakeAt = Number(current);
    this.mark();
    return Number(current);
  }

  async advanceLoop(source = "wake") {
    this.db = this.store.load();
    this.db.loop.lastWakeAt = now();
    this.db.loop.wakeSource = source;
    this.mark();

    if (!this.db.loop.enabled) {
      this.persist();
      return { worked: false, operation: "loop_disabled" };
    }

    this.recoverExpiredLeases();
    let result = null;

    if (this.db.company.activeMeetingId) {
      result = await this.advanceMeeting();
    } else {
      const project = this.nextPlanProject();
      if (project) {
        if (this.providerReadyAt(this.ceo()) <= now()) result = await this.advancePlan(project);
        else result = { worked: false, operation: "plan_provider_wait", nextAt: this.providerReadyAt(this.ceo()) };
      }

      if (!result?.worked) {
        const review = this.nextReviewTask();
        if (review) {
          if (this.providerReadyAt(this.ceo()) <= now()) result = await this.advanceReview(review);
          else if (!result) result = { worked: false, operation: "review_provider_wait", nextAt: this.providerReadyAt(this.ceo()) };
        }
      }

      if (!result?.worked) {
        const task = this.nextAgentTask();
        if (task) result = await this.advanceAgentTask(task);
      }

      if (!result?.worked) {
        if (
          this.db.settings.weeklyMeetings &&
          now() >= Number(this.db.settings.nextWeeklyMeeting || 0) &&
          this.isConfigured(this.ceo()) &&
          this.db.agents.some(a => !a.isCeo && this.isConfigured(a))
        ) {
          const created = this.createMeeting("أسبوعي", "جدولة تلقائية");
          result = created.error
            ? { worked: true, operation: "weekly_meeting_blocked", nextDelayMs: 3600000 }
            : { worked: true, operation: "weekly_meeting_created", nextDelayMs: 1000 };
        }
      }

      if (!result?.worked) {
        const scanDue = this.db.loop.forceScan || (
          this.db.settings.autonomy?.enabled &&
          now() - Number(this.db.settings.autonomy.lastScanAt || 0) >= Number(this.db.settings.autonomy.scanMinutes || 10) * 60000
        );
        if (scanDue && this.isConfigured(this.ceo())) {
          if (this.providerReadyAt(this.ceo()) <= now()) {
            result = await this.runCeoScan(!!this.db.loop.forceScan);
          } else if (!result) {
            result = { worked: false, operation: "scan_provider_wait", nextAt: this.providerReadyAt(this.ceo()) };
          }
        }
      }
    }

    if (!result) result = { worked: false, operation: "idle" };
    this.db.loop.lastOperationAt = now();
    this.db.loop.lastOperation = result.operation || "unknown";
    if (result.worked) this.db.loop.lastError = null;
    this.persist();
    await this.scheduleAfter(result);
    return result;
  }

  async handleAlarm() {
    return this.withLock(async () => {
      this.db.loop.lastAlarmAt = now();
      this.db.loop.wakeSource = "alarm";
      this.persist();
      // منبّه أمان مؤقت: إذا سقطت هذه الاستدعاءة أثناء نداء خارجي، توجد استعادة تلقائية.
      try { if (this.db.loop.enabled && this.setAlarmFn) await this.setAlarmFn(now() + 180000); } catch {}
      try {
        return await this.advanceLoop("alarm");
      } catch (e) {
        this.db.loop.lastError = String(e.message || e).slice(0, 500);
        this.activity("خطأ حلقة", "تعثر استيقاظ الحلقة وسيعاد تلقائيًا: " + this.db.loop.lastError.slice(0, 180));
        this.persist();
        await this.scheduleAfter({ nextDelayMs: 60000 });
        throw e;
      }
    });
  }

  async wakeNow(source = "manual") {
    return this.withLock(async () => {
      try { return await this.advanceLoop(source); }
      catch (e) {
        this.db.loop.lastError = String(e.message || e).slice(0, 500);
        this.persist();
        await this.scheduleAfter({ nextDelayMs: 60000 });
        throw e;
      }
    });
  }

  loopStatus() {
    const s = this.db.loop || {};
    return {
      enabled: !!s.enabled,
      forceScan: !!s.forceScan,
      freeProviderNextAt: s.freeProviderNextAt || 0,
      lastAlarmAt: s.lastAlarmAt || 0,
      lastWakeAt: s.lastWakeAt || 0,
      lastOperationAt: s.lastOperationAt || 0,
      lastOperation: s.lastOperation || null,
      lastError: s.lastError || null,
      nextWakeAt: s.nextWakeAt || null,
      wakeSource: s.wakeSource || null,
      pendingWork: this.hasPendingWork()
    };
  }

  /* ---------- الاستدعاءات وعروض الواجهة ---------- */
  normalizeSummon(agent, mutate = true) {
    if (!agent.summon) agent.summon = { active: false, requestedAt: null, expiresAt: null, dismissedAt: null, slot: null };
    const sm = agent.summon;
    if (sm.active && sm.expiresAt && now() > sm.expiresAt) {
      if (mutate) {
        sm.active = false;
        sm.dismissedAt = now();
        sm.slot = null;
        this.activity("استدعاء", "⏱️ انتهت مدة استدعاء " + agent.name + " لمكتب المالك وعاد تمثيله البصري لمحطة عمله.");
        this.mark();
      }
      return { ...sm, active: false, slot: null };
    }
    return {
      active: !!sm.active,
      requestedAt: sm.requestedAt || null,
      expiresAt: sm.expiresAt || null,
      dismissedAt: sm.dismissedAt || null,
      slot: sm.slot ?? null
    };
  }

  nextSummonSlot(exceptId = "") {
    const used = new Set(this.db.agents
      .filter(a => a.id !== exceptId && this.normalizeSummon(a, false).active)
      .map(a => a.summon.slot)
      .filter(x => Number.isInteger(x)));
    let slot = 0;
    while (used.has(slot)) slot++;
    return slot;
  }

  summonAgentRecord(agent, minutes = 30) {
    const mins = Math.max(5, Math.min(240, parseInt(minutes) || 30));
    agent.summon = {
      active: true, requestedAt: now(), expiresAt: now() + mins * 60000,
      dismissedAt: null, slot: this.nextSummonSlot(agent.id)
    };
    return agent.summon;
  }

  dismissAgentRecord(agent) {
    agent.summon = { ...(agent.summon || {}), active: false, dismissedAt: now(), slot: null };
    return agent.summon;
  }

  agentView(agent) {
    const configured = this.isConfigured(agent);
    const current = this.db.tasks.find(t => t.agentId === agent.id && t.status === "running") ||
      this.db.tasks.find(t => t.agentId === agent.id && t.status === "under_review");
    const run = current?.currentRunId ? this.runById(current.currentRunId) : null;
    const latest = [...this.db.artifacts].reverse().find(x => x.agentId === agent.id);
    const done = this.db.tasks.filter(t => t.agentId === agent.id && t.status === "approved").length;
    const revs = this.db.reviews.filter(r => r.agentId === agent.id);
    return {
      id: agent.id, name: agent.name, role: agent.role, dept: agent.dept, color: agent.color,
      isCeo: agent.isCeo, officeIndex: agent.officeIndex, configured,
      connectionId: agent.connectionId, connectionName: this.connById(agent.connectionId)?.name || null,
      model: agent.model, tools: agent.tools, memory: agent.memory || [], summon: this.normalizeSummon(agent),
      status: !configured ? "unconfigured"
        : this.db.company.activeMeetingId && !agent.isCeo ? "in_meeting"
        : current?.status === "running" ? "working"
        : current?.status === "under_review" ? "awaiting_review" : "idle",
      stats: {
        approvedTasks: done,
        revisions: revs.filter(r => r.verdict !== "approve").length,
        avgScore: revs.length ? Math.round(revs.reduce((s, r) => s + r.score, 0) / revs.length) : null
      },
      currentTask: current ? {
        id: current.id, title: current.title, status: current.status, why: current.why || "",
        projectId: current.projectId, projectTitle: this.projById(current.projectId)?.title || "",
        projectGoal: this.projById(current.projectId)?.goal || "", instructions: current.instructions,
        lastAction: current.lastAction || "", startedAt: current.startedAt || null,
        heartbeatAt: current.heartbeatAt || null, deliverableArtifactId: current.deliverableArtifactId || null,
        run: run ? {
          id: run.id, step: run.step, maxSteps: run.maxSteps || this.db.settings.maxSteps, model: run.model,
          toolsUsed: [...new Set((run.steps || []).filter(s => s.kind === "tool").map(s => s.tool))],
          startedAt: run.startedAt
        } : null
      } : null,
      latestArtifact: latest ? { id: latest.id, title: latest.title, kind: latest.kind, createdAt: latest.createdAt } : null
    };
  }

  /* ---------- ترحيل وتصدير ---------- */
  sanitizeImportedDb(input) {
    const db = normalizeDb(input);
    for (const run of db.runs) {
      if (run.status === "running") {
        run.status = "interrupted";
        run.leaseUntil = 0;
        run.steps = Array.isArray(run.steps) ? run.steps : [];
        run.steps.push({ at: now(), kind: "system", text: "استُرد عند الترحيل إلى Cloudflare — قابل للاستئناف من نقطة الحفظ" });
      }
    }
    for (const task of db.tasks) {
      if (task.status === "running") {
        task.status = "queued";
        task.lastAction = "استُرد عند الترحيل إلى Cloudflare وسيُستأنف";
      }
    }
    if (db.company.activeMeetingId) {
      const meeting = db.meetings.find(m => m.id === db.company.activeMeetingId);
      if (!meeting || meeting.status !== "in_progress") {
        db.company.activeMeetingId = null;
        db.company.paused = false;
      }
    }
    db.loop = { ...db.loop, forceScan: false, freeProviderNextAt: 0, lastError: null, nextWakeAt: null };
    return db;
  }

  exportBundle() {
    const db = JSON.parse(JSON.stringify(this.db));
    const artifactContents = [];
    for (const art of db.artifacts || []) {
      const bytes = this.store.readArtifact(art.id);
      if (!bytes) continue;
      if (art.kind === "text") artifactContents.push({ id: art.id, contentText: new TextDecoder().decode(bytes) });
      else {
        // تصدير ثنائي كامل قد يكون كبيرًا؛ نستخدم Base64 للحفاظ على البايتات كما هي.
        let binary = "";
        const chunk = 0x8000;
        for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
        artifactContents.push({ id: art.id, contentBase64: btoa(binary) });
      }
    }
    return {
      format: "autonomous-ai-company-cloudflare-import",
      version: 1,
      exportedAt: new Date().toISOString(),
      db,
      artifactContents
    };
  }

  async importBundle(payload, { pauseLoop = true } = {}) {
    const inputDb = payload?.db || payload;
    if (!inputDb || typeof inputDb !== "object" || inputDb.version !== 2) {
      throw new Error("حزمة ترحيل غير صالحة: يلزم قاعدة شركة version=2");
    }
    const sanitized = this.sanitizeImportedDb(inputDb);
    sanitized.loop.enabled = !pauseLoop;
    this.store.replaceDb(sanitized, payload?.artifactContents || []);
    this.db = this.store.db;
    this.activity("ترحيل Cloudflare", pauseLoop
      ? "☁️ استُوردت حالة الشركة إلى Cloudflare والحلقة متوقفة مؤقتًا حتى مراجعة المالك وتشغيلها."
      : "☁️ استُوردت حالة الشركة إلى Cloudflare وبدأت حلقة العمل السحابية.");
    this.persist();
    if (this.db.loop.enabled) await this.ensureScheduled(1000, true);
    else await this.scheduleAfter({});
    return {
      projects: this.db.projects.length,
      tasks: this.db.tasks.length,
      taskStatuses: this.db.tasks.reduce((acc, t) => ((acc[t.status] = (acc[t.status] || 0) + 1), acc), {}),
      artifacts: this.db.artifacts.length,
      loop: this.loopStatus()
    };
  }
}

export { PROVIDER_TYPES, TOOL_DEFS, chat, listModels, maskSecret, uid, now };
