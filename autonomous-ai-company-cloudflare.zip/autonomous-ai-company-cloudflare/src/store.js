import { freshDb, normalizeDb } from "./seed.js";
import { base64ToBytes, bytesToBase64 } from "./crypto.js";

const COLLECTIONS = [
  "company", "settings", "connections", "agents", "projects", "tasks", "reviews",
  "approvals", "meetings", "activity", "ceoChat", "agentChats", "decisions", "loop"
];

const CHUNK_BYTES = 24573; // مضاعف 3 حتى لا تظهر حشوة Base64 في منتصف الملف.

function parseJson(value, fallback) {
  try { return JSON.parse(value); } catch { return fallback; }
}

function cleanArtifactMeta(record) {
  if (!record || typeof record !== "object") return record;
  const clean = { ...record };
  delete clean.content;
  delete clean.contentText;
  delete clean.contentBase64;
  delete clean._contentBytes;
  return clean;
}

/**
 * مخزن Durable Object SQLite متزامن الكتابة.
 * - المجموعات الصغيرة محفوظة كصف JSON لكل مجموعة.
 * - runs/artifacts محفوظة صفًا لكل سجل، والحفظ التفاضلي يكتب المتغير فقط.
 * - محتوى المستندات مقسم chunks حتى لا نصطدم بحد 2MB للصف.
 */
export class DurableStore {
  constructor(ctx) {
    if (!ctx?.storage?.sql) throw new Error("Durable Object يجب أن يكون SQLite-backed (تحقق من new_sqlite_classes في wrangler)");
    this.ctx = ctx;
    this.sql = ctx.storage.sql;
    this.db = null;
    this.dirty = false;
    this.snapshots = { collections: new Map(), runs: new Map(), artifacts: new Map() };
    this.init();
  }

  init() {
    this.sql.exec(`CREATE TABLE IF NOT EXISTS collections (
      name TEXT PRIMARY KEY,
      json TEXT NOT NULL,
      updated_at INTEGER NOT NULL
    )`);
    this.sql.exec(`CREATE TABLE IF NOT EXISTS runs (
      id TEXT PRIMARY KEY,
      task_id TEXT,
      project_id TEXT,
      status TEXT,
      updated_at INTEGER NOT NULL,
      json TEXT NOT NULL
    )`);
    this.sql.exec(`CREATE INDEX IF NOT EXISTS runs_task_idx ON runs(task_id)`);
    this.sql.exec(`CREATE INDEX IF NOT EXISTS runs_status_idx ON runs(status)`);
    this.sql.exec(`CREATE TABLE IF NOT EXISTS artifacts (
      id TEXT PRIMARY KEY,
      updated_at INTEGER NOT NULL,
      json TEXT NOT NULL
    )`);
    this.sql.exec(`CREATE TABLE IF NOT EXISTS artifact_chunks (
      artifact_id TEXT NOT NULL,
      idx INTEGER NOT NULL,
      data TEXT NOT NULL,
      PRIMARY KEY (artifact_id, idx)
    )`);
    this.sql.exec(`CREATE TABLE IF NOT EXISTS store_meta (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    )`);
    this.sql.exec(
      "INSERT INTO store_meta(key, value) VALUES('schema', '1') ON CONFLICT(key) DO UPDATE SET value='1'"
    );
  }

  all(query, ...params) {
    const cursor = this.sql.exec(query, ...params);
    return typeof cursor.toArray === "function" ? cursor.toArray() : [...cursor];
  }

  transaction(fn) {
    if (typeof this.ctx.storage.transactionSync === "function") return this.ctx.storage.transactionSync(fn);
    return fn();
  }

  load() {
    if (this.db) return this.db;

    const collectionRows = this.all("SELECT name, json FROM collections");
    if (!collectionRows.length) {
      this.db = freshDb();
      this.snapshots = { collections: new Map(), runs: new Map(), artifacts: new Map() };
      this.saveNow();
      return this.db;
    }

    const raw = { version: 2 };
    const collectionSnapshots = new Map();
    for (const row of collectionRows) {
      raw[row.name] = parseJson(row.json, null);
      collectionSnapshots.set(row.name, row.json);
    }

    const runSnapshots = new Map();
    raw.runs = this.all("SELECT id, json FROM runs").map(row => {
      runSnapshots.set(row.id, row.json);
      return parseJson(row.json, null);
    }).filter(Boolean);
    raw.runs.sort((a, b) => (a.startedAt || 0) - (b.startedAt || 0));

    const artifactSnapshots = new Map();
    raw.artifacts = this.all("SELECT id, json FROM artifacts").map(row => {
      artifactSnapshots.set(row.id, row.json);
      return parseJson(row.json, null);
    }).filter(Boolean);
    raw.artifacts.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));

    this.db = normalizeDb(raw);
    this.snapshots = { collections: collectionSnapshots, runs: runSnapshots, artifacts: artifactSnapshots };
    this.dirty = false;
    return this.db;
  }

  save() { this.dirty = true; }

  saveNow() {
    if (!this.db) this.load();
    const nextSnapshots = {
      collections: new Map(this.snapshots.collections),
      runs: new Map(this.snapshots.runs),
      artifacts: new Map(this.snapshots.artifacts)
    };
    const updatedAt = Date.now();

    this.transaction(() => {
      for (const name of COLLECTIONS) {
        const json = JSON.stringify(this.db[name] ?? null);
        if (nextSnapshots.collections.get(name) === json) continue;
        this.sql.exec(
          `INSERT INTO collections(name, json, updated_at) VALUES(?, ?, ?)
           ON CONFLICT(name) DO UPDATE SET json=excluded.json, updated_at=excluded.updated_at`,
          name, json, updatedAt
        );
        nextSnapshots.collections.set(name, json);
      }

      const seenRuns = new Set();
      for (const run of this.db.runs || []) {
        if (!run?.id) continue;
        seenRuns.add(run.id);
        const json = JSON.stringify(run);
        if (nextSnapshots.runs.get(run.id) === json) continue;
        this.sql.exec(
          `INSERT INTO runs(id, task_id, project_id, status, updated_at, json) VALUES(?, ?, ?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET task_id=excluded.task_id, project_id=excluded.project_id,
             status=excluded.status, updated_at=excluded.updated_at, json=excluded.json`,
          run.id, run.taskId || null, run.projectId || null, run.status || null, updatedAt, json
        );
        nextSnapshots.runs.set(run.id, json);
      }
      for (const id of [...nextSnapshots.runs.keys()]) {
        if (seenRuns.has(id)) continue;
        this.sql.exec("DELETE FROM runs WHERE id=?", id);
        nextSnapshots.runs.delete(id);
      }

      const seenArtifacts = new Set();
      for (const record of this.db.artifacts || []) {
        if (!record?.id) continue;
        seenArtifacts.add(record.id);
        const clean = cleanArtifactMeta(record);
        // لا نترك حقول المحتوى المؤقتة على السجل الحي بعد أول حفظ.
        if (record !== clean) {
          delete record.content;
          delete record.contentText;
          delete record.contentBase64;
          delete record._contentBytes;
        }
        const json = JSON.stringify(clean);
        if (nextSnapshots.artifacts.get(record.id) === json) continue;
        this.sql.exec(
          `INSERT INTO artifacts(id, updated_at, json) VALUES(?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET updated_at=excluded.updated_at, json=excluded.json`,
          record.id, updatedAt, json
        );
        nextSnapshots.artifacts.set(record.id, json);
      }
      for (const id of [...nextSnapshots.artifacts.keys()]) {
        if (seenArtifacts.has(id)) continue;
        this.sql.exec("DELETE FROM artifacts WHERE id=?", id);
        this.sql.exec("DELETE FROM artifact_chunks WHERE artifact_id=?", id);
        nextSnapshots.artifacts.delete(id);
      }
    });

    this.snapshots = nextSnapshots;
    this.dirty = false;
  }

  flush() { if (this.dirty) this.saveNow(); }

  _writeChunks(artifactId, bytes) {
    this.sql.exec("DELETE FROM artifact_chunks WHERE artifact_id=?", artifactId);
    let idx = 0;
    for (let offset = 0; offset < bytes.length; offset += CHUNK_BYTES) {
      const part = bytes.subarray(offset, Math.min(bytes.length, offset + CHUNK_BYTES));
      this.sql.exec(
        "INSERT INTO artifact_chunks(artifact_id, idx, data) VALUES(?, ?, ?)",
        artifactId, idx++, bytesToBase64(part)
      );
    }
    if (!bytes.length) this.sql.exec("INSERT INTO artifact_chunks(artifact_id, idx, data) VALUES(?, 0, '')", artifactId);
  }

  writeArtifact(id, _ext, data) {
    const bytes = data instanceof Uint8Array ? data : new TextEncoder().encode(String(data ?? ""));
    this.transaction(() => this._writeChunks(id, bytes));
  }

  writeArtifactText(id, text) { this.writeArtifact(id, "md", new TextEncoder().encode(String(text ?? ""))); }

  writeArtifactBase64(id, base64) { this.writeArtifact(id, "bin", base64ToBytes(base64)); }

  hasArtifact(id) {
    return this.all("SELECT 1 AS one FROM artifact_chunks WHERE artifact_id=? LIMIT 1", id).length > 0;
  }

  readArtifact(id) {
    const rows = this.all("SELECT data FROM artifact_chunks WHERE artifact_id=? ORDER BY idx ASC", id);
    if (!rows.length) return null;
    const parts = rows.map(r => base64ToBytes(r.data || ""));
    const total = parts.reduce((sum, part) => sum + part.length, 0);
    const out = new Uint8Array(total);
    let offset = 0;
    for (const part of parts) { out.set(part, offset); offset += part.length; }
    return out;
  }

  readArtifactText(id) {
    const bytes = this.readArtifact(id);
    return bytes ? new TextDecoder().decode(bytes) : "";
  }

  replaceDb(nextDb, artifactContents = []) {
    const normalized = normalizeDb(nextDb);
    const oldDb = this.db;
    const oldSnapshots = this.snapshots;
    try {
      this.transaction(() => {
        this.sql.exec("DELETE FROM artifact_chunks");
        this.sql.exec("DELETE FROM artifacts");
        this.sql.exec("DELETE FROM runs");
        this.sql.exec("DELETE FROM collections");
      });
      this.db = normalized;
      this.snapshots = { collections: new Map(), runs: new Map(), artifacts: new Map() };

      // المحتوى قد يأتي داخل سجلات artifacts نفسها أو في قائمة منفصلة من حزمة الترحيل.
      const contents = new Map();
      for (const item of artifactContents || []) if (item?.id) contents.set(item.id, item);
      for (const rec of normalized.artifacts || []) {
        if (rec.contentText !== undefined || rec.contentBase64 !== undefined || rec.content !== undefined) {
          contents.set(rec.id, {
            id: rec.id,
            contentText: rec.contentText ?? (typeof rec.content === "string" ? rec.content : undefined),
            contentBase64: rec.contentBase64
          });
        }
      }
      this.saveNow();
      for (const item of contents.values()) {
        if (item.contentBase64) this.writeArtifactBase64(item.id, item.contentBase64);
        else if (item.contentText !== undefined) this.writeArtifactText(item.id, item.contentText);
      }
      return this.db;
    } catch (e) {
      // SQL نفسه قد يكون تراجع أو لم يتراجع حسب موضع الفشل؛ لا ندّعي استردادًا لم يحدث.
      this.db = oldDb;
      this.snapshots = oldSnapshots;
      throw e;
    }
  }

  stats() {
    const rows = this.all(`SELECT
      (SELECT COUNT(*) FROM runs) AS runs,
      (SELECT COUNT(*) FROM artifacts) AS artifacts,
      (SELECT COALESCE(SUM(LENGTH(data)), 0) FROM artifact_chunks) AS artifactBase64Bytes`);
    return rows[0] || { runs: 0, artifacts: 0, artifactBase64Bytes: 0 };
  }
}
