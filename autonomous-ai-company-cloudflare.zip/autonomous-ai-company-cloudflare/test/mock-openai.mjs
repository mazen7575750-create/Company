import { createServer } from "node:http";

const port = Number(process.env.MOCK_PORT || 8799);
let count = 0;

function send(res, status, body) {
  const text = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(text)
  });
  res.end(text);
}

function allText(messages = []) {
  return messages.map(m => typeof m?.content === "string" ? m.content : JSON.stringify(m?.content || "")).join("\n");
}

function replyFor(messages = []) {
  const text = allText(messages);
  const lastUser = [...messages].reverse().find(m => m?.role === "user")?.content || "";

  if (String(lastUser).includes("أجب بكلمتين فقط: الاتصال يعمل")) {
    return { kind: "connection_test", content: "الاتصال يعمل" };
  }

  if (text.includes("أنت الآن في دور المراجع")) {
    return {
      kind: "ceo_review",
      content: JSON.stringify({
        verdict: "approve",
        score: 96,
        feedback: "الناتج يحقق الهدف ويستند إلى نتيجة الأداة المحفوظة، والبنية واضحة ومكتملة.",
        requiredChanges: []
      })
    };
  }

  if (text.includes("حوّل الهدف إلى خطة مهام")) {
    return {
      kind: "ceo_plan",
      content: JSON.stringify({
        summary: "خطة اختبار من خطوة تنفيذ واحدة تتضمن بحثًا في مستندات الشركة ثم تسليم تقرير قابل للمراجعة.",
        tasks: [
          {
            title: "إعداد تقرير اختبار حلقة Cloudflare",
            agentId: "a4",
            instructions: "ابحث أولًا بأداة docs_search في مستندات الشركة عن «الصحية المتقاعدين»، ثم اكتب تقريرًا عربيًا مختصرًا ومنظمًا يوضح ما وجدته ويثبت أن التنفيذ مر عبر أداة حقيقية ونقطة حفظ.",
            acceptanceCriteria: "وجود عنوان وملخص وقسم لما وجدته الأداة وقسم للاستنتاج، من غير اختراع مصادر خارجية.",
            dependsOn: [],
            rationale: "يوسف متخصص في الكتابة الاحترافية ولديه أداة بحث المستندات."
          }
        ],
        missingCapabilities: []
      })
    };
  }

  if (text.includes("جلسة مسحك الاستقلالي الدوري")) {
    return {
      kind: "ceo_scan",
      content: JSON.stringify({ assessment: "لا إجراء إضافيًا أثناء اختبار Mock.", actions: [{ type: "none" }] })
    };
  }

  if (text.includes("نتيجة أداة docs_search الحقيقية")) {
    const deliverable = [
      "# تقرير اختبار حلقة Cloudflare",
      "",
      "## الملخص",
      "هذا التقرير ناتج من مهمة اختبار محلية بنموذج Mock، الغرض منه إثبات سلامة مسار التخطيط والتنفيذ والحفظ والمراجعة قبل النشر، وليس محتوى إنتاجيًا للمالك.",
      "",
      "## ما أعادته أداة بحث مستندات الشركة",
      "نُفذ بحث فعلي في أرشيف الشركة المحفوظ داخل بيئة الاختبار عن «الصحية المتقاعدين». وصول هذه الرسالة نفسها يعني أن نقطة الحفظ انتقلت من مرحلة النموذج إلى مرحلة الأداة ثم عادت إلى النموذج مع نتيجة الأداة الحقيقية كما قرأها المحرك من مستندات الشركة المستوردة.",
      "",
      "## الاستنتاج",
      "مسار العمل سليم بنيويًا: أنشأ المدير مهمة، بدأ الوكيل تشغيلًا قابلًا للاستئناف، نفذ أداة مستندات حقيقية، ثم سلّم هذا النص ليُحفظ كمستند ويدخل مراجعة المدير في استيقاظ لاحق."
    ].join("\n");
    return {
      kind: "agent_final",
      content: JSON.stringify({
        action: "final",
        deliverable,
        summary: "سلّم تقرير اختبار Cloudflare بعد تنفيذ docs_search من نقطة حفظ."
      })
    };
  }

  if (text.includes("قواعد رد صارمة") && text.includes("مهمتك:")) {
    return {
      kind: "agent_tool_request",
      content: JSON.stringify({
        action: "tool",
        tool: "docs_search",
        args: { query: "الصحية المتقاعدين" }
      })
    };
  }

  return {
    kind: "chat_fallback",
    content: "أنا نموذج Mock المحلي للاختبار، وقد استقبلت الرسالة دون أي نداء لنموذج خارجي."
  };
}

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url || "/", "http://127.0.0.1:" + port);
    if (req.method === "GET" && url.pathname === "/v1/models") {
      return send(res, 200, { object: "list", data: [{ id: "mock-model", object: "model", owned_by: "local-qa" }] });
    }
    if (req.method === "GET" && url.pathname === "/health") {
      return send(res, 200, { ok: true, requests: count });
    }
    if (req.method !== "POST" || url.pathname !== "/v1/chat/completions") {
      return send(res, 404, { error: { message: "not found" } });
    }

    let raw = "";
    for await (const chunk of req) raw += chunk;
    const body = JSON.parse(raw || "{}");
    const result = replyFor(body.messages || []);
    count++;
    console.log("mock request", count, result.kind, "model=" + (body.model || ""));
    return send(res, 200, {
      id: "chatcmpl-mock-" + count,
      object: "chat.completion",
      created: Math.floor(Date.now() / 1000),
      model: body.model || "mock-model",
      choices: [
        {
          index: 0,
          message: { role: "assistant", content: result.content },
          finish_reason: "stop"
        }
      ],
      usage: { prompt_tokens: 100, completion_tokens: 50, total_tokens: 150 }
    });
  } catch (error) {
    console.error(error);
    return send(res, 500, { error: { message: String(error?.message || error) } });
  }
});

server.listen(port, "0.0.0.0", () => {
  console.log("Mock OpenAI-compatible QA server on http://0.0.0.0:" + port + "/v1");
});
