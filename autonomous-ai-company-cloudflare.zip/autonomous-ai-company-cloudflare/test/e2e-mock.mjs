import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

const workerBase = (process.env.WORKER_BASE || "http://127.0.0.1:8787").replace(/\/$/, "");
const mockBaseForWorker = (process.env.MOCK_BASE_FOR_WORKER || "http://127.0.0.1:8799/v1").replace(/\/$/, "");
const token = process.env.QA_OWNER_TOKEN || "qa-owner-token";
const bundlePath = resolve(process.cwd(), "import", "company-import.json");
const testGoal = "اختبار سحابة آمن: تحقق من أن المدير يخطط وأن وكيلًا يستخدم بحث المستندات ثم يسلّم للمراجعة";

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function api(path, options = {}) {
  const response = await fetch(workerBase + path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "x-owner-token": token,
      ...(options.headers || {})
    }
  });
  const text = await response.text();
  let body;
  try { body = JSON.parse(text); } catch { body = { raw: text.slice(0, 1000) }; }
  if (!response.ok) {
    throw new Error(methodLabel(options) + " " + path + " -> HTTP " + response.status + ": " + (body.error || text.slice(0, 500)));
  }
  return body;
}

function methodLabel(options = {}) {
  return String(options.method || "GET").toUpperCase();
}

function assert(condition, message) {
  if (!condition) throw new Error("فشل التحقق: " + message);
}

function testProject(os) {
  return os.projects.find(p => p.goal === testGoal) || null;
}

function summarize(os) {
  const counts = {};
  for (const task of os.tasks) counts[task.status] = (counts[task.status] || 0) + 1;
  const p = testProject(os);
  const tasks = p ? os.tasks.filter(t => t.projectId === p.id) : [];
  return {
    projects: os.projects.length,
    tasks: os.tasks.length,
    taskStatuses: counts,
    runs: os.runs.length,
    artifactsReturnedByOs: os.artifacts.length,
    testProject: p ? { id: p.id, status: p.status } : null,
    testTasks: tasks.map(t => ({ id: t.id, status: t.status, agentId: t.agentId, lastAction: t.lastAction || "" })),
    loop: os.loop
  };
}

async function main() {
  const health = await api("/api/health");
  assert(health.ok === true, "health");
  console.log("HEALTH", {
    runtime: health.runtime,
    authConfigured: health.authConfigured,
    ceoConfiguredBeforeImport: health.ceoConfigured,
    storage: health.storage
  });

  const original = JSON.parse(await readFile(bundlePath, "utf8"));
  const bundle = structuredClone(original);
  let disabled = 0;
  for (const task of bundle.db.tasks || []) {
    if (["queued", "running", "under_review", "blocked_unconfigured"].includes(task.status)) {
      task.status = "cancelled";
      task.checkpointRunId = null;
      task.currentRunId = null;
      task.nextRetryAt = 0;
      task.lastAction = "أُلغيت داخل نسخة QA فقط حتى لا تعمل أثناء اختبار Cloudflare";
      disabled++;
    }
  }
  for (const run of bundle.db.runs || []) {
    if (run.status === "running") {
      run.status = "interrupted";
      run.leaseUntil = 0;
    }
  }
  bundle.db.company.paused = false;
  bundle.db.company.activeMeetingId = null;
  bundle.db.settings.autonomy.enabled = false;
  bundle.db.settings.autonomy.allowAutoProjects = false;
  bundle.db.settings.weeklyMeetings = false;
  delete bundle.db.loop;

  const imported = await api("/api/admin/import", {
    method: "POST",
    body: JSON.stringify({ bundle, pauseLoop: true })
  });
  console.log("IMPORT_SANITIZED_QA_COPY", { disabledLiveTasksInCopy: disabled, summary: imported.summary });

  let os = await api("/api/os");
  console.log("AFTER_IMPORT", summarize(os));

  const conn = await api("/api/connections", {
    method: "POST",
    body: JSON.stringify({
      name: "Mock QA المحلي",
      type: "openai_compatible",
      baseUrl: mockBaseForWorker,
      apiKey: "mock-local-key",
      model: "mock-model"
    })
  });
  console.log("MOCK_CONNECTION", { id: conn.id, type: conn.type, baseUrl: conn.baseUrl, models: conn.models });

  const test = await api("/api/connections/" + conn.id + "/test", {
    method: "POST",
    body: JSON.stringify({ model: "mock-model" })
  });
  assert(test.ok === true, "اختبار اتصال Mock");
  console.log("CONNECTION_TEST", test);

  const models = await api("/api/connections/" + conn.id + "/models", { method: "POST", body: "{}" });
  assert((models.models || []).includes("mock-model"), "قائمة نماذج Mock");
  console.log("MODELS", models);

  const assigned = await api("/api/agents/bulk-assign", {
    method: "POST",
    body: JSON.stringify({ connectionId: conn.id, model: "mock-model", scope: "all" })
  });
  assert(assigned.count === 21, "تعيين Mock لـ21 وكيلًا");
  console.log("BULK_ASSIGN", assigned);

  const project = await api("/api/goals", {
    method: "POST",
    body: JSON.stringify({ goal: testGoal })
  });
  assert(project.status === "planning", "مشروع الاختبار يدخل التخطيط");
  console.log("TEST_GOAL", { id: project.id, status: project.status });

  const loopOn = await api("/api/admin/loop", {
    method: "POST",
    body: JSON.stringify({ enabled: true })
  });
  assert(loopOn.loop.enabled === true, "تشغيل حلقة QA");
  console.log("LOOP_ON", loopOn.loop);

  const operations = [];
  let finished = false;
  for (let i = 1; i <= 12; i++) {
    const wake = await api("/api/admin/wake", { method: "POST", body: "{}" });
    operations.push({ wake: i, ...(wake.result || {}) });
    os = await api("/api/os");
    const p = testProject(os);
    const tasks = p ? os.tasks.filter(t => t.projectId === p.id) : [];
    console.log("WAKE", i, wake.result, "PROJECT", p?.status, "TASKS", tasks.map(t => t.status));
    if (p?.status === "completed" && tasks.length >= 1 && tasks.every(t => t.status === "approved")) {
      finished = true;
      break;
    }
    await sleep(150);
  }
  assert(finished, "اكتمال مشروع Mock واعتماد مهمته خلال 12 استيقاظًا");
  console.log("OPERATIONS", operations);

  os = await api("/api/os");
  const p = testProject(os);
  const task = os.tasks.find(t => t.projectId === p.id);
  assert(task?.deliverableArtifactId, "المهمة لها مستند تسليم");

  const artifact = await api("/api/artifacts/" + task.deliverableArtifactId);
  const content = String(artifact.content || artifact.text || "");
  assert(content.includes("تقرير اختبار حلقة Cloudflare"), "محتوى مستند التسليم");
  assert(content.includes("أداة بحث مستندات الشركة"), "المستند يذكر مرحلة الأداة");
  console.log("DELIVERABLE", {
    id: artifact.id,
    title: artifact.title,
    chars: content.length,
    storage: artifact.storage || artifact.meta?.storage || null
  });

  const run = os.runs.find(r => r.taskId === task.id && r.type === "agent_task");
  assert(run, "وجود تشغيل مهمة Mock");
  const toolSteps = (run.steps || []).filter(s => s.kind === "tool").map(s => s.tool);
  assert(toolSteps.includes("docs_search"), "التشغيل يوثق docs_search");
  console.log("TASK_RUN", { id: run.id, status: run.status, step: run.step, tools: toolSteps });

  const exported = await api("/api/admin/export");
  const exportedDb = exported.db || exported.bundle?.db || exported;
  assert(exportedDb.projects?.some(x => x.id === p.id && x.status === "completed"), "التصدير يحتوي المشروع المكتمل");
  console.log("EXPORT_CHECK", {
    projects: exportedDb.projects.length,
    tasks: exportedDb.tasks.length,
    artifacts: exportedDb.artifacts.length,
    artifactContents: (exported.artifactContents || exported.bundle?.artifactContents || []).length
  });

  const loop = await api("/api/admin/loop");
  console.log("FINAL_LOOP_AND_STORAGE", loop);
  console.log("FINAL_SUMMARY", summarize(os));
  console.log("✅ E2E_MOCK_PASSED");
}

main().catch(error => {
  console.error("❌ E2E_MOCK_FAILED", error?.stack || error);
  process.exit(1);
});
