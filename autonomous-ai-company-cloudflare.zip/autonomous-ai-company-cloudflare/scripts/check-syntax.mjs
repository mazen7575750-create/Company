import { readdir } from "node:fs/promises";
import { extname, join, resolve } from "node:path";
import { spawnSync } from "node:child_process";

async function walk(dir) {
  const out = [];
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) out.push(...await walk(path));
    else if ([".js", ".mjs"].includes(extname(entry.name))) out.push(path);
  }
  return out;
}

const root = resolve(process.cwd());
const files = [];
for (const dir of ["src", "scripts", "test"]) {
  try { files.push(...await walk(join(root, dir))); }
  catch (error) { if (error.code !== "ENOENT") throw error; }
}
files.sort();
for (const file of files) {
  const result = spawnSync(process.execPath, ["--check", file], { encoding: "utf8" });
  if (result.status !== 0) {
    console.error(result.stderr || result.stdout);
    throw new Error("فشل فحص الصياغة: " + file);
  }
  console.log("OK", file.replace(root + "/", ""));
}
console.log("كل ملفات JavaScript سليمة الصياغة:", files.length);
