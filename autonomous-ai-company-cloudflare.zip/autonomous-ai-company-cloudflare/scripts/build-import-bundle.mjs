import { mkdir, readFile, writeFile, access } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const cloudflareDir = resolve(here, "..");
const projectDir = resolve(cloudflareDir, "..");
const dataDir = resolve(projectDir, "backend", "data");
const companyFile = resolve(dataDir, "company.json");
const artifactsDir = resolve(dataDir, "artifacts");
const outFile = resolve(cloudflareDir, "import", "company-import.json");

const db = JSON.parse(await readFile(companyFile, "utf8"));
if (!db || db.version !== 2) throw new Error("company.json ليس قاعدة شركة v2 صالحة");

const artifactContents = [];
const missing = [];
for (const art of db.artifacts || []) {
  const safeId = String(art.id || "").replace(/[^\w-]/g, "");
  const safeExt = String(art.ext || "bin").replace(/[^\w]/g, "") || "bin";
  if (!safeId) continue;
  const file = resolve(artifactsDir, safeId + "." + safeExt);
  try {
    await access(file);
    if (art.kind === "text") {
      artifactContents.push({ id: art.id, contentText: await readFile(file, "utf8") });
    } else {
      artifactContents.push({ id: art.id, contentBase64: (await readFile(file)).toString("base64") });
    }
  } catch {
    missing.push(art.id);
  }
}

const bundle = {
  format: "autonomous-ai-company-cloudflare-import",
  version: 1,
  exportedAt: new Date().toISOString(),
  note: "ملف ترحيل خاص: قد يحتوي db.connections[].secret مشفرة. لا ترفعه إلى GitHub أو أي مكان عام.",
  db,
  artifactContents
};

await mkdir(dirname(outFile), { recursive: true });
await writeFile(outFile, JSON.stringify(bundle), "utf8");

const taskStatuses = (db.tasks || []).reduce((acc, t) => ((acc[t.status] = (acc[t.status] || 0) + 1), acc), {});
console.log("تم بناء حزمة الترحيل:", outFile);
console.log("مشاريع:", (db.projects || []).length, "مهام:", (db.tasks || []).length, JSON.stringify(taskStatuses));
console.log("مستندات:", (db.artifacts || []).length, "محتوى مضمّن:", artifactContents.length, "مفقود من القرص:", missing.length);
if (missing.length) console.log("معرفات المفقود:", missing.join(", "));
