import { access, mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const cloudflareDir = resolve(here, "..");
const projectDir = resolve(cloudflareDir, "..");
const source = resolve(projectDir, "index.html");
const target = resolve(cloudflareDir, "public", "index.html");

async function exists(path) {
  try { await access(path); return true; } catch { return false; }
}

// في مستودع Cloudflare المستقل لا توجد نسخة Node الأم بجانب هذا المجلد،
// لكن public/index.html تكون متزامنة أصلًا داخل الحزمة. في هذه الحالة نتحقق
// من علامتي التعديل ونترك الملف كما هو بدل أن يفشل بناء Git على Cloudflare.
if (!(await exists(source))) {
  if (!(await exists(target))) throw new Error("لم أجد واجهة المصدر ولا public/index.html الجاهزة");
  const ready = await readFile(target, "utf8");
  const markers = ["workers\\.dev|pages\\.dev", "const _timeoutMs="];
  if (!markers.every(m => ready.includes(m))) {
    throw new Error("public/index.html موجودة لكنها لا تحمل تعديلات Cloudflare المطلوبة");
  }
  console.log("واجهة Cloudflare الجاهزة موجودة ومتزامنة:", target, "(" + ready.length + " حرف)");
  process.exit(0);
}

let html = await readFile(source, "utf8");

function replaceOnce(search, replacement, label) {
  if (!html.includes(search)) throw new Error("لم أجد موضع تعديل الواجهة: " + label);
  html = html.replace(search, replacement);
}

// على workers.dev/pages.dev تكون الواجهة والـAPI من نفس الأصل دائمًا،
// حتى لو كان متصفح المالك محتفظًا برابط خادم تجريبي قديم من نسخة Node.
replaceOnce(
  "function normalizeServerUrl(u){",
  "function normalizeServerUrl(u){\n  if(SAME_ORIGIN&&/(workers\\.dev|pages\\.dev)$/.test(location.hostname))return SAME_ORIGIN;",
  "normalizeServerUrl"
);

// طلبات القراءة تبقى سريعة، أما المحادثات واختبارات النماذج فقد تحتاج أكثر من 15 ثانية.
replaceOnce(
  "const signal=opt.signal||(typeof AbortSignal!==\"undefined\"&&AbortSignal.timeout?AbortSignal.timeout(15000):undefined);",
  "const _timeoutMs=String(opt.method||\"GET\").toUpperCase()===\"GET\"?15000:180000;\n  const signal=opt.signal||(typeof AbortSignal!==\"undefined\"&&AbortSignal.timeout?AbortSignal.timeout(_timeoutMs):undefined);",
  "api timeout"
);

await mkdir(dirname(target), { recursive: true });
await writeFile(target, html, "utf8");
console.log("تمت مزامنة الواجهة إلى", target, "(" + html.length + " حرف)");
